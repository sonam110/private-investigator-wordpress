<?php
return array(
	'title'      => 'Insighteye Team Setting',
	'id'         => 'insighteye_meta_team',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'team' ),
	'sections'   => array(
		array(
			'id'     => 'insighteye_team_meta_setting',
			'fields' => array(
				array(
					'id'    => 'designation',
					'type'  => 'text',
					'title' => esc_html__( 'Designation', 'insighteye' ),
				),
				array(
					'id'    => 'social_profile',
					'type'  => 'textarea',
					'title' => esc_html__( 'Social Profiles', 'insighteye' ),
				),
				array(
                    'id' => 'show_imges',
                    'type' => 'switch',
                    'title' => esc_html__('Show/Hide Detail Images', 'insighteye'),
                    'desc' => esc_html__('Enable to Show Detail Images', 'insighteye'),
                ),
				array(
					'id'       => 'bg_img',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Background Image', 'insighteye' ),
					'desc'     => esc_html__( 'Insert Background Image URl', 'insighteye' ),
					'required' => array('show_imges', '=', true),
				),
				array(
					'id'       => 'signature_img',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Signature Image', 'insighteye' ),
					'desc'     => esc_html__( 'Insert Signature Image URl', 'insighteye' ),
					'required' => array('show_imges', '=', true),
				),
				array(
                    'id' => 'show_experience_box',
                    'type' => 'switch',
                    'title' => esc_html__('Show/Hide Experience Box', 'insighteye'),
                    'desc' => esc_html__('Enable to Show Experience Box', 'insighteye'),
                ),
				array(
					'id'    => 'experience_title',
					'type'  => 'text',
					'title' => esc_html__( 'Experience Title', 'insighteye' ),
					'required' => array('show_experience_box', '=', true),
				),
				array(
					'id'    => 'experience_text',
					'type'  => 'text',
					'title' => esc_html__( 'Experience Text', 'insighteye' ),
					'required' => array('show_experience_box', '=', true),
				),
				array(
                    'id' => 'show_team_info',
                    'type' => 'switch',
                    'title' => esc_html__('Show/Hide Team Info', 'insighteye'),
                    'desc' => esc_html__('Enable to Show Team Info', 'insighteye'),
                ),
				array(
					'id'    => 'contact_title',
					'type'  => 'text',
					'title' => esc_html__( 'Contact Title', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
				array(
					'id'    => 'skill_title',
					'type'  => 'text',
					'title' => esc_html__( 'Skill Title', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
				array(
					'id'    => 'skill',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Skill', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
				array(
					'id'    => 'email_title',
					'type'  => 'text',
					'title' => esc_html__( 'Email Title', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
				array(
					'id'    => 'email_address',
					'type'  => 'text',
					'title' => esc_html__( 'Email Address', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
				array(
					'id'    => 'phone_title',
					'type'  => 'text',
					'title' => esc_html__( 'Phone Title', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
				array(
					'id'    => 'phone_no',
					'type'  => 'text',
					'title' => esc_html__( 'Phone Number', 'insighteye' ),
					'required' => array('show_team_info', '=', true),
				),
			),
		),
	),
);