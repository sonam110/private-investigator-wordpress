<?php
	return array(
		'title'      => 'insighteye post Setting',
		'id'         => 'insighteye_post',
		'icon'       => 'el el-cogs',
		'position'   => 'normal',
		'priority'   => 'core',
		'post_types' => array( 'post' ),
		'sections'   => array(
			array(
				'fields' => array(					
				),
			),
		),
	);


?>