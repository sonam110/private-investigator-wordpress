(function($) {
	
	"use strict";
		var slider_carousels_js = function($scope, $) {

		
		// five-item-carousel
		var design_one = $('.five-item-carousel'); 
		if(design_one.length){
		var slider_attr = $('#yt-client-slider').data('slider');
		$('.five-item-carousel').owlCarousel({
			loop:slider_attr.infinite,
			margin:slider_attr.item_gap,
			nav:true,
			smartSpeed: slider_attr.autoplaySpeed,
			autoplay: slider_attr.autoplay,
			navText: [ '<span class="fal fa-angle-left"></span>', '<span class="fal fa-angle-right"></span>' ],
			responsive:{
				0:{
					items:1
				},
				480:{
					items:2
				},
				600:{
					items:3
				},
				800:{
					items:4
				},			
				1200:{
					items:slider_attr.item_show
				}

			}
		});    		
	 }
		
	};
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/insighteye_client_carousel.default', slider_carousels_js);
    });	

})(window.jQuery);