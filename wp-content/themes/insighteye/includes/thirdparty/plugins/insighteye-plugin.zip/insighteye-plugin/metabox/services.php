<?php
return array(
	'title'      => 'Insighteye Service Setting',
	'id'         => 'insighteye_meta_service',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'service' ),
	'sections'   => array(
		array(
			'id'     => 'insighteye_service_meta_setting',
			'fields' => array(
									
			),
		),
	),
);