<?php namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Choose_Us extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'insighteye_choose_us';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Insighteye Choose Us', 'insighteye' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
  public function get_icon() {
        return 'eicon-welcome';
    }
	
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'insighteye' ];
    }
	
	public function get_script_depends() {
		wp_register_script( 'counter-slider', YT_URL . 'assets/js/counter.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'counter-slider' ];
	}
	
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'choose_us',
            [
                'label' => esc_html__( 'Choose Us', 'insighteye' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'insighteye'),
					'2' => esc_html__( 'Style Two ', 'insighteye'),
					'3' => esc_html__( 'Style Three ', 'insighteye'),
				),
			]
		);
		$this->add_control(
            'show_pattern_img',
			[
				'label' => __( 'Enable/Disable Pattern Image', 'insighteye' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enable/Disable Pattern Image', 'insighteye' ),
			]
		);
		$this->add_control(
			'choose_us_image',
			[
				'label' => __( 'Choose Us Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'   => [ 'layout_control' => '2', ],
			]
		);
		$this->add_control(
			'author_image',
			[
				'label' => __( 'Author Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		$this->add_control(
			'sub_title',
			[
				'label'       => __( 'Sub Title', 'insighteye' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'insighteye' ),
			]
		);	
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'insighteye' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Description', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'insighteye' ),
			]
		);
		$this->add_control(
			'features_list',
			[
				'label'       => __( 'Feature List', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [ 'layout_control' => '2', ],
				'placeholder' => __( 'Enter your Feature List', 'insighteye' ),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'insighteye' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'insighteye' ),
			]
		);
		$this->add_control(
			'btn_link',
			[
				  'label' => __( 'External Url', 'insighteye' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				  'show_external' => true,
				  'default' => [
				    'url' => '',
				    'is_external' => true,
				    'nofollow' => true,
				  ],
			 ]
		);	
		//Feature Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'icon_img',
			[
				'label' => __( 'Icon Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	
		$repeater->add_control(
			'block_title',
			[
				'label'       => __( 'Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'insighteye' ),
			]
		);
		$this->add_control(
			'feature',
			[
				'label'                 => __('Add Feature Item', 'insighteye'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		//Feature 1 Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'icon_img',
			[
				'label' => __( 'Icon Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	
		$repeater->add_control(
			'block_title',
			[
				'label'       => __( 'Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'insighteye' ),
			]
		);
		$this->add_control(
			'feature_1',
			[
				'label'                 => __('Add Features Item', 'insighteye'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		//Feature 2 Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'icon_img',
			[
				'label' => __( 'Icon Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	
		$repeater->add_control(
			'block_title',
			[
				'label'       => __( 'Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'block_text',
			[
				'label'       => __( 'Text', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'insighteye' ),
			]
		);
		$this->add_control(
			'feature_2',
			[
				'label'                 => __('Add Features Item', 'insighteye'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'   => [ 'layout_control' => '3', ],
			]
		);
		//Funfact Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'icons',
			[
				'label' => esc_html__('Enter The icons', 'insighteye'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'flaticon-mail',
					'library' => 'solid',
				],
			]			
		);
		$repeater->add_control(
			'counter_start',
			[
				'label' => esc_html__( 'Counter Start', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,			
				'placeholder' => esc_html__( 'Enter your Counter Start', 'insighteye' ),
				'default' => esc_html__( '0', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'counter_stop',
			[
				'label' => esc_html__( 'Counter Stop', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Counter Stop', 'insighteye' ),
				'default' => esc_html__( '45', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'alphabet_letter',
			[
				'label' => esc_html__( 'Alphabet Letter', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Alphabet Letter', 'insighteye' ),
				'default' => esc_html__( 'k', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'block_title',
			[
				'label'       => __( 'Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'insighteye' ),
			]
		);
		$this->add_control(
			'funfact',
			[
				'label'                 => __('Add Funfact Item', 'insighteye'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'   => [ 'layout_control' => '2', ],
			]
		);
		$this->end_controls_section();
		
		
		
		/** Style Tab **/
		$this->register_style_background_controls();
    }
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
	protected function register_style_background_controls()
	{
		/**Layout Control Style**/		
		$this->start_controls_section(
			'insighteye_layout_style',
			[
				'label' => esc_html__('Insighteye Layout Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_margin',
			[
				'label'              => __( 'Spacing', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .insight-choose-us' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_padding',
			[
				'label'              => __( 'Gapping', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .insight-choose-us' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_control(
			'insighteye_layout_background',
			[
				'label'                 => __( 'Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'insighteye_layout_bgtype',
				'label' => __( 'Button Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .insight-choose-us',				
			]
		);
		$this->end_controls_section();
		
		//Sub Title Style
		$this->start_controls_section(
			'subtitle_style',
			[
				'label' => esc_html__( 'Sub Title', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .sec-title .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .sec-title .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .sec-title .sub-title',				
			]
		);
		
		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Title Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sec-title .sub-title' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .sec-title .sub-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '{{WRAPPER}} .sec-title .sub-title',
			]
		);

		$this->end_controls_section();
		
		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .sec-title h2',				
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .sec-title h2',
			]
		);

		$this->end_controls_section();
		
		//Text Style
		
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .insight-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .insight-text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_text_shadow',
				'selector' => '{{WRAPPER}} .insight-text',
			]
		);
		$this->end_controls_section();
		
		//Feature List Style		
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '2',
				]
			]
		);	
		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-style-one li:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'service_icon_border_type',
				'selector' => 
					'{{WRAPPER}} .list-style-one li:before',				
				'separator' => 'before',
			]
		);
		$this->add_control(
			'service_icon_border_radius',
			[
				'label' => esc_html__('Icon Border Radius', 'insighteye'),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .list-style-one li:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);	
		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-style-one li' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .list-style-one li',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_text_shadow',
				'selector' => '{{WRAPPER}} .list-style-one li',
			]
		);
		$this->end_controls_section();
	
		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'insighteye_tabs_btn' );
		
			$this->start_controls_tab(
				'insighteye_tab_btn_normal',
				[
					'label' => __( 'Normal', 'insighteye' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-button',
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'width: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'height: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'btn_margin',
					[
						'label'              => __( 'Margin', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type',
						'selector' => 
							'{{WRAPPER}} .insight-button',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' => 
							'{{WRAPPER}} .insight-button',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'insighteye'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'btn_title_typography',
						'label' => __('Button Text Typography', 'insighteye'),
						'selector' => 
							'{{WRAPPER}} .insight-button',				
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'color: {{VALUE}}!important',
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'insighteye_tab_btn_hover',
				[
					'label' => __( 'Hover', 'insighteye' ),
				]
			);
			
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-button:hover:before',				
					]
				);
				
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-button:hover' => 'border-color: {{VALUE}}!important',
						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-button:hover' => 'color: {{VALUE}}!important',
						],
						'separator' => 'before',
					]
				);
			
			$this->end_controls_tab();			
		$this->end_controls_tabs();   
		$this->end_controls_section();
		
		
		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('Loop Style Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		//Background
		$this->add_control(
			'show_loop_bg_style',
			[
				'label'       => __( 'ON/OFF Loop Shape Background Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_control(
			'loop_background',
			[
				'label'                 => __( 'Shape Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_loop_bg_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'loop_bgtype',
				'label' => __( 'Shape Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .chooseus-block-one .inner-box,
					 {{WRAPPER}} .funfact-block-two .inner-box,
					 {{WRAPPER}} .chooseus-style-three .inner-box .single-item
					 
					',
				'condition'             => [
					'show_loop_bg_style'    => 'yes',
				]			
			]
		);
		//Loop Icon
		$this->add_control(
			'show_icon_style',
			[
				'label'       => __( 'ON/OFF Loop Icon Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_control(
			'loop_icon_background',
			[
				'label'                 => __( 'Icon Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_icon_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'loop_icon_bgtype',
				'label' => __( 'Icon Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .chooseus-block-one .inner-box .icon-box,
					 {{WRAPPER}} .funfact-block-two .inner-box .icon-box,
					 {{WRAPPER}} .chooseus-style-three .inner-box .single-item .icon-box					 
					',
				'condition'             => [
					'show_icon_style'    => 'yes',
				]			
			]
		);
		//Icon Color Style
		$this->add_control(
			'loop_icon_color',
			[
				'label'                 => __( 'Icon Color', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'layout_control'    => '2',
					'show_icon_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'loop_icon_color_bgtype',
				'types' => [ 'classic', 'gradient' ],
				'selector' => 
					'{{WRAPPER}} .funfact-block-two .inner-box .icon-box .icon
					',
				'condition'             => [
					'layout_control'    => '2',
					'show_icon_style'    => 'yes',
				]			
			]
		);
		//Loop Counter Style
		$this->add_control(
			'show_loop_counter_style',
			[
				'label'       => __( 'ON/OFF Loop Counter Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'layout_control'    => '2',
				]
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_counter_typography',
                'label' => __('Loop Counter Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .funfact-block-two .inner-box .count-outer',             
                'separator' => 'before',
				'condition'             => [
					'show_loop_counter_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_counter_color',
            [
                'label' => __('Loop Counter Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .funfact-block-two .inner-box .count-outer' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_counter_style'    => 'yes',
				]
            ]
        );
		
		//Loop Title
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF Loop Title Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Loop Title Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .chooseus-block-one .inner-box h3,
					 {{WRAPPER}} .funfact-block-two .inner-box h3,
					 {{WRAPPER}} .chooseus-style-three .inner-box .single-item h4
					',             
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Loop Title Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .chooseus-block-one .inner-box h3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .funfact-block-two .inner-box h3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .chooseus-style-three .inner-box .single-item h4' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		
		//Loop Text
		$this->add_control(
			'show_loop_text_style',
			[
				'label'       => __( 'ON/OFF Loop Text Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'layout_control'    => '3',
				]
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_text_typography',
                'label' => __('Loop Text Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .chooseus-style-three .inner-box .single-item p
					',             
                'separator' => 'before',
				'condition'             => [
					'show_loop_text_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_text_color',
            [
                'label' => __('Loop Text Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .chooseus-style-three .inner-box .single-item p' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_text_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
	}

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
	?>
	    
    <?php if( $layout === '3' ): ?>
    
     <!-- chooseus-style-three -->
    <section class="chooseus-style-three sec-pad-2 insight-choose-us">
        <?php if($settings[ 'show_pattern_img' ]){ ?>
        <div class="pattern-layer">
            <div class="pattern-1"></div>
            <div class="pattern-2 rotate-me" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-5.png);"></div>
            <div class="pattern-3"></div>
            <div class="pattern-4"></div>
        </div>
        <?php } ?>
        <div class="auto-container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <?php if($settings[ 'sub_title'] || $settings[ 'title']){ ?>
                    <div class="content-box mr_70">
                        <div class="sec-title mb_25">
                            <?php if($settings[ 'sub_title']){ ?>
                            <span class="sub-title"><?php echo wp_kses( $settings[ 'sub_title'], true  );?></span>
							<?php } ?>
                            <?php if($settings[ 'title']){ ?>
                            <h2><?php echo wp_kses( $settings[ 'title'], true  );?></h2>
							<?php } ?>
                        </div>
                        <?php } ?>
                        <div class="text-box">
                        	<?php if($settings[ 'text']){ ?>
                            <p class="insight-text"><?php echo wp_kses( $settings[ 'text'], true  );?></p>
                            <?php } ?>
                            <?php if($settings[ 'btn_link']['url'] and $settings[ 'btn_title']){ ?>
                            <a href="<?php echo esc_url( $settings[ 'btn_link']['url'] );?>" class="theme-btn btn-one insight-button"><?php echo wp_kses( $settings[ 'btn_title'], true  );?></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 inner-column">
                    <div class="inner-box mr_50">
                         <?php foreach($settings['feature_2'] as $key => $item): ?>
                        <div class="single-item <?php if($key == 1) echo 'ml_50'; ?>">
                            <?php if( $item[ 'icon_img' ]['id']){ ?>
                            <div class="icon-box"><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'icon_img' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"></div>
                            <?php } ?>
                            <?php if($item[ 'block_title' ]){ ?>
                            <h4><?php echo wp_kses( $item[ 'block_title'], true  );?></h4>
							<?php } ?>
                            <?php if($item[ 'block_text' ]){ ?>
                            <p><?php echo wp_kses( $item[ 'block_text'], true  );?></p>
                            <?php } ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- chooseus-style-three end -->
    
    
    <?php elseif( $layout === '2' ): ?>
    
        <!-- chooseus-style-two -->
        <section class="chooseus-style-two pt_150 pb_70 insight-choose-us">
            <?php if($settings[ 'choose_us_image' ]['id'] ){ ?>
            <div class="bg-layer" style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $settings[ 'choose_us_image' ]['id'] ) );?>);"></div>
			<?php } ?>
            <?php if($settings[ 'show_pattern_img' ]){ ?>
            <div class="pattern-layer">
                <div class="pattern-1 float-bob-y" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-11.png);"></div>
                <div class="pattern-2"></div>
                <div class="pattern-3 rotate-me"></div>
            </div>
            <?php } ?>
            <div class="auto-container">
                <div class="content_block_four">
                    <div class="content-box pb_70">
                        <?php if($settings[ 'show_pattern_img' ]){ ?>
                        <div class="shape" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-10.png);"></div>
                        <?php } ?>
                        <div class="inner-box">
                            <?php if($settings[ 'sub_title'] || $settings[ 'title']){ ?>
                            <div class="sec-title mb_25">
                                <?php if($settings[ 'sub_title']){ ?> 
                                <span class="sub-title"><?php echo wp_kses( $settings[ 'sub_title'], true  );?></span>
							    <?php } ?>
                                <?php if($settings[ 'title']){ ?>
                                <h2><?php echo wp_kses( $settings[ 'title'], true  );?></h2>
								<?php } ?>
                            </div>
                            <?php } ?>
                            <div class="text-box mb_30">
                                <?php if($settings[ 'text']){ ?>
                                <p class="insight-text"><?php echo wp_kses( $settings[ 'text'], true  );?></p>
								<?php } ?>
                                <?php $features_list = $settings['features_list'];
									if(!empty($features_list)){
									$features_list = explode("\n", ($features_list)); 
								?>
								<ul class="list-style-one clearfix">
									<?php foreach($features_list as $features): ?>
										<li><?php echo wp_kses($features, true); ?></li>
									 <?php endforeach; ?>
								</ul>
								<?php } ?>
                            </div>
                             <?php if($settings[ 'btn_link']['url'] and $settings[ 'btn_title']){ ?>
                            <div class="btn-box">
                                <a href="<?php echo esc_url( $settings[ 'btn_link']['url'] );?>" class="theme-btn btn-one insight-button"><?php echo wp_kses( $settings[ 'btn_title'], true  );?></a>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="funfact-inner clearfix">
                            <?php foreach($settings['funfact'] as $key => $item):
								  $icon = $item['icons'];	 
							?>
                            <div class="funfact-block-two">
                                <div class="inner-box">
                                    <div class="icon-box"><div class="icon gradient-color">
                                    	<?php if( !empty( $icon ) ):?>
											<?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                                        <?php else:?>
                                            <i class="icon-7"></i>
                                        <?php endif;?> 
                                    </div></div>
                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="1500" data-stop="<?php echo wp_kses($item['counter_stop'], true ) ;?>"><?php echo wp_kses($item['counter_start'], true ) ;?></span><span><?php echo wp_kses($item['alphabet_letter'], true ) ;?></span>
                                    </div>
                                    <?php if($item['block_title']){ ?><h3><?php echo wp_kses($item['block_title'], true ) ;?></h3><?php } ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- chooseus-style-two end -->
    
    <?php else: ?>  
    
    
    	 <!-- chooseus-section -->
        <section class="chooseus-section pt_150 pb_150 insight-choose-us">
            <?php if($settings[ 'show_pattern_img' ] || $settings[ 'author_image' ]['id']){ ?>
            <div class="pattern-layer">
                <div class="pattern-1"></div>
                <?php if($settings[ 'show_pattern_img' ]){ ?>
                <div class="pattern-2 rotate-me" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-5.png);"></div>
                <?php } ?>
                <?php if($settings[ 'author_image' ]['id']){ ?>
                <div class="pattern-3" style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $settings[ 'author_image' ]['id'] ) );?>);"></div>
				<?php } ?>
            </div>
            <?php } ?>
            <div class="auto-container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_two">
                            <div class="content-box mr_70">
                                <?php if($settings[ 'sub_title'] || $settings[ 'title']){ ?>
                                <div class="sec-title mb_25">
                                     <?php if($settings[ 'sub_title']){ ?>
                                    <span class="sub-title"><?php echo wp_kses( $settings[ 'sub_title'], true  );?></span>
									<?php } ?>
                                    <?php if($settings[ 'title']){ ?>
                                    <h2><?php echo wp_kses( $settings[ 'title'], true  );?></h2>
									<?php } ?>
                                </div>
                                <?php } ?>
                                <div class="text-box">
									<?php if($settings[ 'text']){ ?>
                                    <p class="insight-text"><?php echo wp_kses( $settings[ 'text'], true  );?></p>
                                    <?php } ?>
                                    <?php if($settings[ 'btn_link']['url'] and $settings[ 'btn_title']){ ?>
                                    <a href="<?php echo esc_url( $settings[ 'btn_link']['url'] );?>" class="theme-btn btn-one insight-button"><?php echo wp_kses( $settings[ 'btn_title'], true  );?></a>
									<?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 inner-column">
                        <div class="inner-content ml_50">
                            <?php if($settings[ 'show_pattern_img' ]){ ?>
                            <div class="shape">
                                <div class="shape-1"></div>
                                <div class="shape-2"></div>
                                <div class="shape-3 rotate-me"></div>
                            </div>
                            <?php } ?>
                            <div class="row align-items-center">
                                <div class="col-lg-6 col-md-6 col-sm-12 chooseus-block">
                                    <?php foreach($settings['feature'] as $key => $item): ?>
                                    <div class="chooseus-block-one">
                                        <div class="inner-box mb_30">
                                            <?php if($item[ 'icon_img' ]){ ?>
                                            <div class="icon-box"><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'icon_img' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"></div>
											<?php } ?>
                                            <?php if($item[ 'block_title' ]){ ?><h3><?php echo wp_kses( $item[ 'block_title'], true  );?></h3><?php } ?>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 chooseus-block">
                                	<?php foreach($settings['feature_1'] as $key => $item): ?>
                                    <div class="chooseus-block-one">
                                        <div class="inner-box">
                                            <?php if($item[ 'icon_img' ]){ ?>
                                            <div class="icon-box"><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'icon_img' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"></div>
											<?php } ?>
                                            <?php if($item[ 'block_title' ]){ ?><h3><?php echo wp_kses( $item[ 'block_title'], true  );?></h3><?php } ?>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- chooseus-section end -->

    
    <?php endif;
    }
}
