<?php namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Icon_Box extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'insighteye_icon_box';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Insighteye Icon Box', 'insighteye' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'insighteye' ];
    }
	
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'icon_box',
            [
                'label' => esc_html__( 'Icon Box', 'insighteye' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'insighteye'),
					'2' => esc_html__( 'Style Two ', 'insighteye'),
					'3' => esc_html__( 'Style Three ', 'insighteye'),
					'4' => esc_html__( 'Style Four ', 'insighteye'),
					'5' => esc_html__( 'Style Five ', 'insighteye'),
				),
			]
		);
		
		$this->add_control(
			'icons',
			[
				'label' => esc_html__('Enter The icons', 'buildnox'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'flaticon-mail',
					'library' => 'solid',
				],
			]			
		);		
		
		$this->add_responsive_control(
			'icon_align',
			[
				'label' => esc_html__( 'Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .icon' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'insighteye' ),
				'default' => esc_html__( 'Administration', 'insighteye' ),
				'condition'   => [ 'layout_control' => ['1','2','4','5'] ],
			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'insighteye' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'insighteye' ),
				'default' => esc_html__( 'Of City Council', 'insighteye' ),
				'condition'   => [ 'layout_control' => ['1','2','4','5'] ],
			]
		);
		$this->add_control(
			'shape_image',
			[
				'label' => esc_html__( 'Choose Shape Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'layout_control' => ['4',]
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'phone_title',
			[
				'label' => esc_html__( 'Phone Title', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Phone Title', 'insighteye' ),
				'default' => esc_html__( 'Administration', 'insighteye' ),
				'condition'   => [ 'layout_control' => '3', ],
			]
		);
		$this->add_control(
			'phone_no',
			[
				'label' => esc_html__( 'Phone Number', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Phone Number', 'insighteye' ),
				'default' => esc_html__( 'Administration', 'insighteye' ),
				'condition'   => [ 'layout_control' => '3', ],
			]
		);
		$this->end_controls_section();
		
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .insight-section .insight-content-box',
			]
		);
		$this->end_controls_section();
		
		
		
		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .insight-title',
			]
		);
		
		$this->add_control(
			'title_color',
			[

				'label' => esc_html__( 'Title Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .insight-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .insight-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '{{WRAPPER}} .insight-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .insight-title',
			]
		);
		$this->end_controls_section();
		
		//Text Style		
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .insight-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .insight-text' => 'color: {{VALUE}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .insight-text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_text_shadow',
				'selector' => '{{WRAPPER}} .insight-text',
			]
		);
		$this->end_controls_section();
		
		/**Icon Box Style**/
		$this->start_controls_section(
			'icon_box_style',
			[
				'label' => esc_html__('Icon Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => ['1','5']
				]
			]
		);
		$this->start_controls_tabs( 'insighteye_service_icon_tab' );		
			$this->start_controls_tab(
				'insighteye_service_icon_normal',
				[
					'label' => __( 'Normal', 'insighteye' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'icon_box_bgtype',
						'label' => __( 'Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-icon,
							 {{WRAPPER}} .content_block_six .content-box .inner-box .single-item .icon-box
							',				
					]
				);
				$this->add_control(
					'more_icon_color',
					[
						'label' => esc_html__( 'Icon Color', 'insighteye' ),
						'type' => \Elementor\Controls_Manager::HEADING,
						'separator' => 'before',
						'condition'             => [
							'layout_control'    => '1'
						]
					]
				);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'icon_box_bgtype_icon',
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-icon .icon,
							 {{WRAPPER}} .content_block_six .content-box .inner-box .single-item .icon-box .icon
							',
						'condition'             => [
							'layout_control'    => '1'
						]			
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'service_icon_typography',
						'label' => __('Icon Typography', 'insighteye'),
						'selector' => 
							'{{WRAPPER}} .insight-icon',                 
						'separator' => 'before',						
					]
				);
				$this->add_responsive_control(
					'icon_box_space',
					[
						'label'              => __( 'Space', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_responsive_control(
					'icon_box_padding',
					[
						'label'              => __( 'Padding', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],						
						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'service_icon_border_type',
						'selector' => 
							'{{WRAPPER}} .insight-icon',				
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'service_icon_box_shadow',
						'selector' => 
							'{{WRAPPER}} .insight-icon',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'service_icon_border_radius',
					[
						'label' => esc_html__('Border Radius', 'insighteye'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .insight-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .content_block_six .content-box .inner-box .single-item .icon-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'insighteye_services_icon_box_hover',
				[
					'label' => __( 'Hover', 'insighteye' ),
				]
			);
			
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'service_icon_hover_bg_bgtype',
						'label' => __( 'BG Hover Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-section:hover .insight-icon:before',				
					]
				);
				$this->add_control(
					'more_icon_hover_color',
					[
						'label' => esc_html__( 'Icon Hover Color', 'insighteye' ),
						'type' => \Elementor\Controls_Manager::HEADING,
						'separator' => 'before',
					]
				);				
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'service_icon_hover_color',
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-section:hover .insight-icon .icon',
					]
				);
			$this->end_controls_tab();			
		$this->end_controls_tabs();   
		$this->end_controls_section();	
		
		
		
		/**Icon Box Style**/
		$this->start_controls_section(
			'icon_box_style_v2',
			[
				'label' => esc_html__('Icon Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [ 'layout_control' => '2' ]
			]
		);
		$this->start_controls_tabs( 'insighteye_service_icon_tab_v2' );
		
			$this->start_controls_tab(
				'insighteye_service_icon_normal_v2',
				[
					'label' => __( 'Normal', 'insighteye' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'icon_box_bgtype_v2',
						'label' => __( 'Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-icon',				
					]
				);
				$this->add_control(
					'service_icon_color_v2',
					[
						'label' => __('Icon Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-icon' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'service_icon_typography_v2',
						'label' => __('Icon Typography', 'insighteye'),
						'selector' => 
							'{{WRAPPER}} .insight-icon',                 
						'separator' => 'before',						
					]
				);
				$this->add_responsive_control(
					'icon_box_space_v2',
					[
						'label'              => __( 'Space', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_responsive_control(
					'icon_box_padding_v2',
					[
						'label'              => __( 'Padding', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'service_icon_border_type_v2',
						'selector' => 
							'{{WRAPPER}} .insight-icon',				
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'service_icon_box_shadow_v2',
						'selector' => 
							'{{WRAPPER}} .insight-icon',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'service_icon_border_radius_v2',
					[
						'label' => esc_html__('Border Radius', 'insighteye'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .insight-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'insighteye_services_icon_box_hover_v2',
				[
					'label' => __( 'Hover', 'insighteye' ),
				]
			);
			
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'service_icon_hover_bg_bgtype_v2',
						'label' => __( 'BG Hover Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-section:hover .insight-icon:before,				
										 .insight-icon:hover',				
					]
				);		
				$this->add_control(
					'service_icon_hover_color_v2',
					[
						'label' => __('Icon Hover Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-section:hover .insight-icon' => 'color: {{VALUE}}',
							'{{WRAPPER}} .insight-icon:hover' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();			
		$this->end_controls_tabs();   
		$this->end_controls_section();	
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
		$icon = $settings['icons'];
	?>
    
    	<?php if( $layout == 5 ):?>
       
        <div class="content_block_six insight-section">
            <div class="content-box insight-content-box">
             	<div class="inner-box">
                    <div class="single-item">
                        <div class="icon-box insight-icon">
                        	<div class="icon gradient-color ">
                            <?php if( !empty( $icon ) ):?>
                                <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                            <?php endif;?>
                            </div>
                        </div>
                      <?php if($settings['title']){ ?><h3 class="insight-title"><?php echo wp_kses($settings['title'], true ) ;?></h3><?php } ?>
                      <?php if($settings['text']){ ?><p class="insight-text"><?php echo wp_kses($settings['text'], true ) ;?></p><?php } ?>
                   </div>
                </div>
             </div>
         </div>
         
        <?php elseif( $layout == 4 ):?>
        
        <div class="content_block_three insight-section">
            <div class="content-box insight-content-box">
                <?php if($settings['shape_image']['id']){ ?>
                <div class="shape rotate-me" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>);"></div>
                <?php } ?>
                <div class="inner-box">
                    <div class="row clearfix">
                        <div class="single-item">
                         <div class="icon-box gradient-color insight-icon">
                            <?php if( !empty( $icon ) ):?>
                                <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                            <?php else:?>
                                <i class="icon icon-9"></i>
                            <?php endif;?>
                          </div>
                          <?php if($settings['title']){ ?><h3 class="insight-title"><?php echo wp_kses($settings['title'], true ) ;?></h3><?php } ?>
               			  <?php if($settings['text']){ ?><p class="insight-text"><?php echo wp_kses($settings['text'], true ) ;?></p><?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
       <?php elseif( $layout == 3 ):?>
       
        <div class="contact-section phone insight-section">
        	<div class="content-box insight-content-box">
            	<div class="support-box">
				   	<?php if( !empty( $icon ) ):?>
                   	<div class="icon icon-box insight-icon">
                        <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                   	</div>
                   	<?php endif;?>
                    
                    <?php if($settings['phone_title']){ ?><h4 class="insight-title"><?php echo wp_kses($settings['phone_title'], true ) ;?></h4><?php } ?>
                    <?php if($settings['phone_no']){ ?>
                    <h3 class="insight-text"><a href="tel:<?php echo esc_attr($settings['phone_no'], true ) ;?>"><?php echo wp_kses($settings['phone_no'], true ) ;?></a></h3><?php } ?>
                </div>
        	</div>
        </div>
       
       <?php elseif( $layout == 2 ):?>
       
       <div class="feature-block-two insight-section">
           <div class="inner-box insight-content-box">
               <div class="icon icon-box insight-icon">
					<?php if( !empty( $icon ) ):?>
						<?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                    <?php else:?>
                        <i class="icon-12"></i>
                    <?php endif;?>
               </div>
               <?php if($settings['title']){ ?><h3 class="insight-title"><?php echo wp_kses($settings['title'], true ) ;?></h3><?php } ?>
               <?php if($settings['text']){ ?><p class="insight-text"><?php echo wp_kses($settings['text'], true ) ;?></p><?php } ?>
           </div>
       </div>
		
		<?php else:?>
        
        <div class="feature-block-one insight-section">
            <div class="inner-box insight-content-box">
                <div class="icon-box insight-icon">
                    <div class="icon gradient-color ">
						<?php if( !empty( $icon ) ):?>
                            <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                        <?php else:?>
                            <i class="icon-9"></i>
                        <?php endif;?> 
                    </div>
                </div>
                <?php if($settings['title']){ ?><h3 class="insight-title"><?php echo wp_kses($settings['title'], true ) ;?></h3><?php } ?>
                <?php if($settings['text']){ ?><p class="insight-text"><?php echo wp_kses($settings['text'], true ) ;?></p><?php } ?>
            </div>
        </div>
        
    <?php endif;
    }
}