<?php

namespace INSIGHTEYEPLUGIN\Inc;


use INSIGHTEYEPLUGIN\Inc\Abstracts\Taxonomy;


class Taxonomies extends Taxonomy {


	public static function init() {

		$labels = array(
			'name'              => _x( 'Project Category', 'wpinsighteye' ),
			'singular_name'     => _x( 'Project Category', 'wpinsighteye' ),
			'search_items'      => __( 'Search Category', 'wpinsighteye' ),
			'all_items'         => __( 'All Categories', 'wpinsighteye' ),
			'parent_item'       => __( 'Parent Category', 'wpinsighteye' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpinsighteye' ),
			'edit_item'         => __( 'Edit Category', 'wpinsighteye' ),
			'update_item'       => __( 'Update Category', 'wpinsighteye' ),
			'add_new_item'      => __( 'Add New Category', 'wpinsighteye' ),
			'new_item_name'     => __( 'New Category Name', 'wpinsighteye' ),
			'menu_name'         => __( 'Project Category', 'wpinsighteye' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'project_cat' ),
		);

		register_taxonomy( 'project_cat', 'project', $args );
		
		$labels = array(
			'name'              => _x( 'Service Category', 'wpinsighteye' ),
			'singular_name'     => _x( 'Service Category', 'wpinsighteye' ),
			'search_items'      => __( 'Search Category', 'wpinsighteye' ),
			'all_items'         => __( 'All Categories', 'wpinsighteye' ),
			'parent_item'       => __( 'Parent Category', 'wpinsighteye' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpinsighteye' ),
			'edit_item'         => __( 'Edit Category', 'wpinsighteye' ),
			'update_item'       => __( 'Update Category', 'wpinsighteye' ),
			'add_new_item'      => __( 'Add New Category', 'wpinsighteye' ),
			'new_item_name'     => __( 'New Category Name', 'wpinsighteye' ),
			'menu_name'         => __( 'Service Category', 'wpinsighteye' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'service_cat' ),
		);

		register_taxonomy( 'service_cat', 'service', $args );
	
		
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wpinsighteye' ),
			'singular_name'     => _x( 'Testimonials Category', 'wpinsighteye' ),
			'search_items'      => __( 'Search Category', 'wpinsighteye' ),
			'all_items'         => __( 'All Categories', 'wpinsighteye' ),
			'parent_item'       => __( 'Parent Category', 'wpinsighteye' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpinsighteye' ),
			'edit_item'         => __( 'Edit Category', 'wpinsighteye' ),
			'update_item'       => __( 'Update Category', 'wpinsighteye' ),
			'add_new_item'      => __( 'Add New Category', 'wpinsighteye' ),
			'new_item_name'     => __( 'New Category Name', 'wpinsighteye' ),
			'menu_name'         => __( 'Testimonials Category', 'wpinsighteye' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);


		register_taxonomy( 'testimonials_cat', 'testimonials', $args );
		
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wpinsighteye' ),
			'singular_name'     => _x( 'Team Category', 'wpinsighteye' ),
			'search_items'      => __( 'Search Category', 'wpinsighteye' ),
			'all_items'         => __( 'All Categories', 'wpinsighteye' ),
			'parent_item'       => __( 'Parent Category', 'wpinsighteye' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpinsighteye' ),
			'edit_item'         => __( 'Edit Category', 'wpinsighteye' ),
			'update_item'       => __( 'Update Category', 'wpinsighteye' ),
			'add_new_item'      => __( 'Add New Category', 'wpinsighteye' ),
			'new_item_name'     => __( 'New Category Name', 'wpinsighteye' ),
			'menu_name'         => __( 'Team Category', 'wpinsighteye' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);


		register_taxonomy( 'team_cat', 'team', $args );
		
		
		
	}
	
}
