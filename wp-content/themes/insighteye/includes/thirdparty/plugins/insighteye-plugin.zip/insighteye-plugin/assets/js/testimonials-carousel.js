(function($) {
	
	"use strict";
	var testi_carousel_js = function($scope, $) {
		
		 // single-item-carousel
		 var design_one = $('.single-item-carousel'); 
		 if(design_one.length){
			 var slider_attr = $('#yt-testimonial-slider').data('slider');
			$('.single-item-carousel').owlCarousel({
				loop:slider_attr.infinite,
				margin:slider_attr.item_gap,
				nav:slider_attr.arrows,
				smartSpeed: slider_attr.autoplaySpeed,
				autoplay: slider_attr.autoplay,
				navText: [ '<span class="icon-15"></span>', '<span class="icon-16"></span>' ],
				responsive:{
					0:{
						items:1
					},
					480:{
						items:1
					},
					600:{
						items:1
					},
					800:{
						items:1
					},			
					1200:{
						items:slider_attr.item_show
					}
	
				}
			});    		
		}
	
		var design_two = $('.testimonial-style-two .bxslider'); 	
		 if(design_two.length){
			 var slider_attr = $('#yt-testimonial-two-slider').data('slider');
			$('.testimonial-style-two .bxslider').bxSlider({
				nextText: '<i class="icon-16"></i>',
				prevText: '<i class="icon-15"></i>',
				mode: 'fade',
				auto: slider_attr.autoplay,
				speed: slider_attr.autoplaySpeed,
				pagerCustom: '.testimonial-style-two .slider-pager .thumb-box'
			});
		}
		
	};
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/insighteye_testimonials_carousel.default', testi_carousel_js);
    });	

})(window.jQuery);