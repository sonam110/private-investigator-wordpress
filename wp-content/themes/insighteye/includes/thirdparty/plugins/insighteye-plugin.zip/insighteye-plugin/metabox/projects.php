<?php
return array(
	'title'      => 'Insighteye Project Setting',
	'id'         => 'insighteye_meta_projects',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'project' ),
	'sections'   => array(
		array(
			'id'     => 'insighteye_projects_meta_setting',
			'fields' => array(
				array(
                    'id' => 'show_project_summery',
                    'type' => 'switch',
                    'title' => esc_html__('Show/Hide Project Summery', 'insighteye'),
                    'desc' => esc_html__('Enable to Show Project Summery', 'insighteye'),
                ),
				array(
					'id'    => 'project_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Title', 'insighteye' ),
					'required' => array('show_project_summery', '=', true),
				),
				array(
					'id'    => 'project_text',
					'type'  => 'textarea',
					'title' => esc_html__( 'Project Description', 'insighteye' ),
					'required' => array('show_project_summery', '=', true),
				),
				array(
                    'id' => 'show_project_info',
                    'type' => 'switch',
                    'title' => esc_html__('Show/Hide Project Info', 'insighteye'),
                    'desc' => esc_html__('Enable to Show Project Info', 'insighteye'),
                ),
				array(
					'id'    => 'project_info_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Info Title', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'projrct_client_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Client Title', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_client_name',
					'type'  => 'text',
					'title' => esc_html__( 'Project Client Name', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_date_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Date Title', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_address_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Address Title', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_address',
					'type'  => 'text',
					'title' => esc_html__( 'Project Address', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_category_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Category Title', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_duration_title',
					'type'  => 'text',
					'title' => esc_html__( 'Project Duration Title', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_duration',
					'type'  => 'text',
					'title' => esc_html__( 'Project Duration', 'insighteye' ),
					'required' => array('show_project_info', '=', true),
				),
			),
		),
	),
);