<?php namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Blog_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'insighteye_blog_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Insighteye Blog Grid', 'insighteye' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'insighteye' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'blog_grid',
            [
                'label' => esc_html__( 'Blog Grid', 'insighteye' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'one' => esc_html__( 'Style One ', 'insighteye'),
					'two' => esc_html__( 'Style Two ', 'insighteye'),
				),
			]
		);
		
		$this->add_control(
            'date',
            [
                'label'        => esc_html__( 'Show Date', 'insighteye' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'insighteye' ),
                'label_off'    => esc_html__( 'Off', 'insighteye' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
            'comment',
            [
                'label'        => esc_html__( 'Show Comment', 'insighteye' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'insighteye' ),
                'label_off'    => esc_html__( 'Off', 'insighteye' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
            'author',
            [
                'label'        => esc_html__( 'Show Author', 'insighteye' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'insighteye' ),
                'label_off'    => esc_html__( 'Off', 'insighteye' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );		
		$this->add_control(
			'btn_title',
			[
				'label' => esc_html__( 'Button Title', 'insighteye' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter button title', 'insighteye' ),
				'default' => esc_html__( 'Read More', 'insighteye' ),
			]
		);
		$this->add_control(
			'show_pagination',
			[
				'label'       => __( 'Enable/Disable Pagination Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'insighteye' ),
				'label_off' => __( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [ 'layout_control' => 'one', ],
			]
		);			
		
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default', 'insighteye' ),
					'one' => esc_html__( 'One Column Grid ', 'insighteye'),
					'two'  => esc_html__( 'Two Column Grid', 'insighteye' ),
					'three'  => esc_html__( 'Three Column Grid', 'insighteye' ),
					'four'  => esc_html__( 'Four Column Grid', 'insighteye' ),
					'five'  => esc_html__( 'Six Column Grid', 'insighteye' ),
				),
			]
		);
		
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'insighteye' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);		
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'insighteye' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'insighteye' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'insighteye' ),
                    'title'      => esc_html__( 'Title', 'insighteye' ),
                    'menu_order' => esc_html__( 'Menu Order', 'insighteye' ),
                    'rand'       => esc_html__( 'Random', 'insighteye' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'insighteye' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'insighteye' ),
                    'ASC'  => esc_html__( 'ASC', 'insighteye' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'insighteye'),
				'label_block' => true,
                'options' => get_blog_categories(),
            ]
        );
		
		$this->end_controls_section();
		
		
		/************************************************************************
									Tab Style Start
		*************************************************************************/
	
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .news-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .news-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .news-section',				
			]
		);
		$this->end_controls_section();
		
		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('Loop Style Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		//Background
		$this->add_control(
			'show_loop_bg_style',
			[
				'label'       => __( 'ON/OFF Loop Background Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_control(
			'loop_background',
			[
				'label'                 => __( 'Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_loop_bg_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'loop_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .news-block-one .inner-box',
				'condition'             => [
					'show_loop_bg_style'    => 'yes',
				]			
			]
		);
		
		//Loop Date 
		$this->add_control(
			'show_loop_date_style',
			[
				'label'       => __( 'ON/OFF Post Date Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'date_bg_bgtype',
				'label' => __( 'category Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => 
					'{{WRAPPER}} .news-block-one .inner-box .date',				
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);	
		$this->add_control(
            'loop_date_color',
            [
                'label' => __('Date Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .date' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
            ]
        );
		
		/**Post Meta Description Style**/
		$this->add_control(
			'show_loop_meta_style',
			[
				'label'       => __( 'ON/OFF Post Meta Description Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'post_meta_typography',
                'label' => __('Post Meta Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content .post-info li',
                'separator' => 'before',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_meta_color',
            [
                'label' => __('Post Meta Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content .post-info li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .news-block-one .inner-box .lower-content .post-info li a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_meta_hover_color',
            [
                'label' => __('Post Meta Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content .post-info li a:hover' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
            ]
        );
		//Title
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF Loop Title Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Loop Title Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content h3',             
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Loop Title Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content h3 a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_hover_color',
            [
                'label' => __('Loop Title Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content h3 a:hover' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		//Content
		$this->add_control(
			'show_loop_content_style',
			[
				'label'       => __( 'ON/OFF Loop Content Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_content_typography',
                'label' => __('Loop Content Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content p',
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_content_color',
            [
                'label' => __('Loop Content Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content p' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		//Button Style
		$this->add_control(
			'show_loop_btn_style',
			[
				'label'       => __( 'ON/OFF Loop Button Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_btn_typography',
                'label' => __('Loop Button Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content .link a',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_btn_color',
            [
                'label' => __('Loop Button Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content .link a' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_btn_hover_color',
            [
                'label' => __('Loop Button Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .news-block-one .inner-box .lower-content .link a:hover' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();	
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$comnt = $settings[ 'comment' ];
		$date = $settings[ 'date' ];
		$author = $settings[ 'author' ];
		$btn_title = $settings[ 'btn_title' ]; 
		
		$grid_col = $settings[ 'col_grid' ];
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-3 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-4 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}
		
		$paged = get_query_var('paged');
		$paged = insighteye_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-greenture' );
        $args = array(
            'post_type'      => 'post',
            'posts_per_page' => insighteye_set( $settings, 'query_number' ),
            'orderby'        => insighteye_set( $settings, 'query_orderby' ),
            'order'          => insighteye_set( $settings, 'query_order' ),
            'paged'         => $paged
        );
        if( insighteye_set( $settings, 'query_category' ) ) $args['category_name'] = insighteye_set( $settings, 'query_category' );
        $query = new \WP_Query( $args );
		if ( $query->have_posts() ) { 
	?>
    
    
    <?php if($settings['layout_control'] == 'two') :?>
    
     <section class="news-section">
        <div class="row clearfix">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
             <div class="<?php echo esc_attr( $classes );?> news-block">
                <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                    <div class="inner-box">
                        <?php if(has_post_thumbnail()){ ?>
                        <div class="image-box">
                            <figure class="image"><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_post_thumbnail('insighteye_350x221'); ?></a></figure>
                            <?php if( $date == 'yes' ){?><div class="date"><?php echo get_the_date('d'); ?> <span><?php echo get_the_date('M'); ?></span></div><?php } ?>
                        </div>
                        <?php } ?>
                        <div class="lower-content">
                            <ul class="post-info mb_13 clearfix">
                                <?php if( $author == 'yes' ){?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-4.svg" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><?php the_author(); ?></a></li><?php } ?>
                                <?php if( $comnt == 'yes' ){?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-5.svg" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"><?php comments_number( wp_kses(__('0 Comments' , 'insighteye'), true), wp_kses(__('01 Comment' , 'insighteye'), true), wp_kses(__('0% Comments' , 'insighteye'), true)); ?></li><?php } ?>
                            </ul>
                            <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                            <p><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></p>
                            <div class="link">
                                <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
                                	<span>
                                    	<?php if( !empty( $btn_title ) ):?>
                                            <?php echo wp_kses( $btn_title, true );?>
                                        <?php else:?>
                                            <?php esc_html_e('Read More', 'insighteye');?>
                                        <?php endif;?>
                                   </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
    
    <?php else: ?>    
    
    <!-- news-section -->
    <section class="news-section">
        <div class="row clearfix">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
            <div class="<?php echo esc_attr( $classes );?> news-block">
                <div class="news-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="inner-box">
                        <?php if(has_post_thumbnail()){ ?>
                        <figure class="image-box"><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_post_thumbnail('insighteye_350x221'); ?></a></figure>
                        <?php } ?>
                        <div class="lower-content">
                            <?php if( $date == 'yes' ){?><div class="date"><?php echo get_the_date('d'); ?> <span><?php echo get_the_date('M'); ?></span></div><?php } ?>
                            <ul class="post-info mb_13 clearfix">
                                <?php if( $author == 'yes' ){?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-4.svg" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><?php the_author(); ?></a></li><?php } ?>
                                <?php if( $comnt == 'yes' ){?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-5.svg" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"><?php comments_number( wp_kses(__('0 Comments' , 'insighteye'), true), wp_kses(__('01 Comment' , 'insighteye'), true), wp_kses(__('0% Comments' , 'insighteye'), true)); ?></li><?php } ?>
                            </ul>
                            <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                            <p><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></p>
                            <div class="link">
                                <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
                                	<span>
										<?php if( !empty( $btn_title ) ):?>
                                            <?php echo wp_kses( $btn_title, true );?>
                                        <?php else:?>
                                            <?php esc_html_e('Read More', 'insighteye');?>
                                        <?php endif;?>
                               		</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php if($settings['show_pagination']) : ?>
        <div class="pagination-wrapper centred pt_50">
           <?php insighteye_the_pagination2(array('total'=>$query->max_num_pages, 'next_text' => '<i class="fal fa-angle-right"></i>', 'prev_text' => '<i class="fal fa-angle-left"></i>')); ?>
        </div>
         <?php endif; ?>
    </section>    
    <!-- news-section end -->

    <?php endif; ?>
   	<?php }
	wp_reset_postdata();
	}
}