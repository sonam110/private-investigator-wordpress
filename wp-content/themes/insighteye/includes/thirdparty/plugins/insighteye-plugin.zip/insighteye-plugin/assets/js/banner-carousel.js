(function($) {
	
	"use strict";
		var slider_carousels_js = function($scope, $) {

		
		// banner-carousel
		var design_one = $('.banner-carousel'); 
		if(design_one.length){
			var slider_attr = $('.banner-carousel').data('slider');
			$('.banner-carousel').owlCarousel({
				loop:slider_attr.infinite,
				margin:slider_attr.item_gap,
				nav:true,
				animateOut: 'fadeOut',
				animateIn: 'fadeIn',
				active: true,
				smartSpeed: slider_attr.autoplaySpeed,
				autoplay: slider_attr.autoplay,
				navText: [ '<span class="icon-15"></span>', '<span class="icon-16"></span>' ],
				responsive:{
					0:{
						items:1
					},
					600:{
						items:1
					},
					800:{
						items:1
					},
					1024:{
						items:slider_attr.item_show
					}
				}
			});
		}
		
		
	};
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/insighteye_main_slider.default', slider_carousels_js);
    });	

})(window.jQuery);