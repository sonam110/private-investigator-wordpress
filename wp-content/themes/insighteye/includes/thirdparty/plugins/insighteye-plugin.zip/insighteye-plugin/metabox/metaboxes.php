<?php
if ( ! function_exists( "insighteye_add_metaboxes" ) ) {
	function insighteye_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'projects.php',
			'services.php',
			'team.php',
			'testimonials.php',
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( INSIGHTEYEPLUGIN_PLUGIN_PATH . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/insighteye_options/boxes", "insighteye_add_metaboxes" );
}

