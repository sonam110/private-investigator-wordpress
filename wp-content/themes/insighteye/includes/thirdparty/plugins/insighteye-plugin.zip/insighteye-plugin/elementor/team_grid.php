<?php namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Team_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'insighteye_team_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Insighteye Team Grid', 'insighteye' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'insighteye' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'team_grid',
            [
                'label' => esc_html__( 'Team Grid', 'insighteye' ),
            ]
        );
		$this->add_control(
			'style_two',
			[
				'label'   => esc_html__( 'Choose Different Style', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'one' => esc_html__( 'Choose Style V1', 'insighteye' ),
					'two' => esc_html__( 'Choose Style V2 ', 'insighteye' ),
					'three' => esc_html__( 'Choose Style V3 ', 'insighteye' ),
				),
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'insighteye' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default', 'insighteye' ),
					'one' => esc_html__( 'One Column Grid ', 'insighteye'),
					'two'  => esc_html__( 'Two Column Grid', 'insighteye' ),
					'three'  => esc_html__( 'Three Column Grid', 'insighteye' ),
					'four'  => esc_html__( 'Four Column Grid', 'insighteye' ),
					'five'  => esc_html__( 'Six Column Grid', 'insighteye' ),
				),
			]
		);
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'insighteye' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'insighteye' ),
                    'title'      => esc_html__( 'Title', 'insighteye' ),
                    'menu_order' => esc_html__( 'Menu Order', 'insighteye' ),
                    'rand'       => esc_html__( 'Random', 'insighteye' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'insighteye' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'insighteye' ),
                    'ASC'  => esc_html__( 'ASC', 'insighteye' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
				'label' => esc_html__('Category', 'insighteye'),
				'label_block' => true,
				'options' => get_team_categories()
            ]
        );
		
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .team-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team-style-two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team-style-three' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .team-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team-style-two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team-style-three' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .team-section,				
							   {{WRAPPER}} .team-style-two,				
							   {{WRAPPER}} .team-style-three',				
			]
		);
		$this->end_controls_section();
		
		/**Loop Item Style**/
		$this->start_controls_section(
			'loop_title_style',
			[
				'label' => esc_html__('Loop Style Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);		
		//Title
		$this->add_control(
			'show_loop_author_title_style',
			[
				'label'       => __( 'ON/OFF Loop Author Title Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Loop Author Title Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .team-block-one .inner-box .lower-content h3,                 
                     {{WRAPPER}} .team-block-two .inner-box .content-box h3,                 
                     {{WRAPPER}} .team-block-three .inner-box .content-box h3',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_author_title_color',
            [
                'label' => __('Loop Author Title Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .team-block-one .inner-box .lower-content h3 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-block-two .inner-box .content-box h3 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-block-three .inner-box .content-box h3 a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_author_title_hover_color',
            [
                'label' => __('Loop Author Title Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .team-block-one .inner-box .lower-content h3 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-block-two .inner-box .content-box h3 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-block-three .inner-box .content-box h3 a:hover' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_title_style'    => 'yes',
				]
            ]
        );
		//Designation
		$this->add_control(
			'show_loop_author_designation_style',
			[
				'label'       => __( 'ON/OFF Loop Author Designation Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_designation_typography',
                'label' => __('Loop Author Designation Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .team-block-one .inner-box .lower-content .designation,                 
                     {{WRAPPER}} .team-block-two .inner-box .content-box .designation,                 
                     {{WRAPPER}} .team-block-three .inner-box .content-box .designation',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_designation_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_author_designation_color',
            [
                'label' => __('Loop Author Designation Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .team-block-one .inner-box .lower-content .designation' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-block-two .inner-box .content-box .designation' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-block-three .inner-box .content-box .designation' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_designation_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$grid_col = $settings[ 'col_grid' ];
		
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-6 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}
		
		
		$paged = get_query_var('paged');
		$paged = insighteye_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;
		
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-greenture' );
        
		$args = array(
			'post_type'      => 'team',
			'posts_per_page' => insighteye_set( $settings, 'query_number' ),
			'orderby'        => insighteye_set( $settings, 'query_orderby' ),
			'order'          => insighteye_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( insighteye_set( $settings, 'query_category' ) ) $args['team_cat'] = insighteye_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	{ ?>
      
      
     <?php if($settings['style_two'] == 'three'): ?>   
     
     <section class="team-style-three">         
        <div class="row clearfix">
     		<?php 
				 while ( $query->have_posts() ) : $query->the_post();
			  ?>
              <div class="col-lg-4 col-md-6 col-sm-12 team-block centred">
                    <div class="team-block-three wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <?php if(has_post_thumbnail()):?>
                            <figure class="image-box"><?php the_post_thumbnail('insighteye_410x451'); ?></figure>
                            <?php endif; ?>
                            <div class="content-box">
                                <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                                <?php if(get_post_meta( get_the_id(), 'designation', true )) { ?>
                                <span class="designation"><?php echo (get_post_meta( get_the_id(), 'designation', true ));?></span>
                                <?php } ?>
                                <?php if(get_post_meta( get_the_id(), 'social_profile', true )){ ?>
                                <ul class="social-links clearfix">
                                    <?php echo (get_post_meta( get_the_id(), 'social_profile', true ));?>
                                </ul>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
              <?php endwhile; ?>
        </div>
     </section>
     
     
     <?php elseif($settings['style_two'] == 'two'): ?>   
      
     <section class="team-style-two">         
        <div class="row clearfix">
          <?php 
		     while ( $query->have_posts() ) : $query->the_post();
		  ?>
          <div class="<?php echo esc_attr( $classes );?> team-block">
            <div class="team-block-two wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                <div class="inner-box">
                    <?php if(has_post_thumbnail()):?>
                    <figure class="image-box"><?php the_post_thumbnail('insighteye_410x451'); ?></figure>
                    <?php endif; ?>
                    <?php if(get_post_meta( get_the_id(), 'social_profile', true )){ ?>
                    <div class="share-box">
                        <div class="share-icon"><i class="fas fa-share-alt"></i></div>
                        <ul class="social-links clearfix">
                            <?php echo (get_post_meta( get_the_id(), 'social_profile', true ));?>		
                        </ul>
                    </div>
                    <?php } ?>
                    <div class="content-box">
                        <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                        <?php if(get_post_meta( get_the_id(), 'designation', true )) : ?>
                        <span class="designation"><?php echo (get_post_meta( get_the_id(), 'designation', true ));?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>   
	  </div>
    </section>  


	<?php else: ?> 


     <section class="team-section">         
        <div class="row clearfix">
            <?php 
				while ( $query->have_posts() ) : $query->the_post();
			?>
            <div class="<?php echo esc_attr( $classes );?> team-block centred">
                <div class="team-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="inner-box">
                          <?php if(has_post_thumbnail()):?>
                          <figure class="image-box"><?php the_post_thumbnail('insighteye_410x451'); ?></figure>
                          <?php endif; ?>
                        <div class="lower-content">
                            <?php if(get_post_meta( get_the_id(), 'social_profile', true )){ ?>
                            <div class="share-box">
                                <div class="share-icon"><i class="fas fa-share-alt"></i></div>
                                <ul class="social-links clearfix">
                                   <?php echo (get_post_meta( get_the_id(), 'social_profile', true ));?>		
                                </ul>
                            </div>
                            <?php } ?>
                            <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                            <?php if(get_post_meta( get_the_id(), 'designation', true )) : ?>
                            <span class="designation"><?php echo (get_post_meta( get_the_id(), 'designation', true ));?></span>
							<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>   
        </div>
      </section>    
    
    
   	 <?php  endif; }
	 wp_reset_postdata();
	}
}