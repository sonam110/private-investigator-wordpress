<?php

namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Testimonials_Carousel extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'insighteye_testimonials_carousel';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Insighteye Testimonials Carousel', 'insighteye' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'insighteye' ];
	}
	
	public function get_script_depends() {
		wp_register_script( 'testimonial-carousel', YT_URL . 'assets/js/testimonials-carousels.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'testimonial-carousel' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonials_carousel',
			[
				'label' => esc_html__( 'Testimonials Carousel', 'insighteye' ),
			]
		);
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'insighteye'),
					'2' => esc_html__( 'Style Two ', 'insighteye'),
				),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [ 'layout_control' => '1', ],
				'placeholder' => __( 'Enter your Title', 'insighteye' ),
			]
		);
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'insighteye' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'insighteye' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'insighteye' ),
					'title'      => esc_html__( 'Title', 'insighteye' ),
					'menu_order' => esc_html__( 'Menu Order', 'insighteye' ),
					'rand'       => esc_html__( 'Random', 'insighteye' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'insighteye' ),
					'ASC'  => esc_html__( 'ASC', 'insighteye' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'insighteye'),
			  'label_block' => true,
			  'options' => get_testimonials_categories(),
			]
		);
		$this->add_control(
			'feature_image',
			[
				'label' => __( 'Feature Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		$this->end_controls_section();
		
		/**Carousel Setting Start**/
		$this->start_controls_section(
			'carousel',
			[
				'label' => esc_html__( 'Carousel Setting', 'insighteye' ),
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		$this->add_control(
			'infinite',
			[
				'label' => __( 'infinite Loop?', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'insighteye' ),
				'label_off' => __( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
			'items_show',
			[
				'label' => esc_html__( 'No. of Items', 'insighteye' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'default' => 1,
			]
		);
		$this->add_responsive_control(
			'image_item_gap',
			[
				'label' => __( 'Item Gap', 'insighteye' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'default' => 30,
			]
		);
		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Autoplay?', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'insighteye' ),
				'label_off' => __( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'autoplay_speed',
			array(
				'label'       => __( 'Animation Speed', 'insighteye' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '1000', 'insighteye' ),
			)
		);
		$this->add_control(
            'insighteye_nav_heading',
            [
                'label' => __('Navigation', 'insighteye'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
			]
        );
		$this->add_control(
			'arrows',
			[
				'label' => __( 'Enable Arrows?', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'insighteye' ),
				'label_off' => __( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'dots',
			[
				'label' => __( 'Enable Dots?', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'insighteye' ),
				'label_off' => __( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->end_controls_section();
	
		/** Style Tab **/
		$this->register_style_background_controls();
    }
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
	protected function register_style_background_controls()
	{
		
		/**Layout Control Style**/		
		$this->start_controls_section(
			'insighteye_layout_style',
			[
				'label' => esc_html__('Insighteye Layout Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'insighteye_layout_margin',
            [
                'label'              => __( 'Spacing', 'insighteye' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .testimonial-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .testimonial-style-two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
				'frontend_available' => true,
				
            ]
        );
		$this->add_responsive_control(
            'insighteye_layout_padding',
            [
                'label'              => __( 'Gapping', 'insighteye' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .testimonial-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .testimonial-style-two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
				'frontend_available' => true,
				
            ]
        );
		$this->add_control(
			'insighteye_layout_background',
			[
				'label'                 => __( 'Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'insighteye_layout_bgtype',
				'label' => __( 'Section Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .testimonial-section,
					 {{WRAPPER}} .testimonial-style-two
					',				
			]
		);
		$this->end_controls_section();
		
		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'adova' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'adova' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .sec-title .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'adova' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .sec-title .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'adova' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .sec-title .sub-title',				
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'adova' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sec-title .sub-title' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'adova'),
				'selector' => '{{WRAPPER}} .sec-title .sub-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .sec-title .sub-title',
			]
		);

		$this->end_controls_section();
		
		/**Loop Item Style**/
		$this->start_controls_section(
			'loop_title_style',
			[
				'label' => esc_html__('Loop Style Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);		
		//Rating
		$this->add_control(
			'show_loop_rating_style',
			[
				'label'       => __( 'ON/OFF Loop Rating Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_rating_color',
            [
                'label' => __('Loop Rating Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block-one .text-box .rating li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .testimonial-style-two .content-box .rating li' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_rating_style'    => 'yes',
				]
            ]
        );
		//Content
		$this->add_control(
			'show_loop_content_style',
			[
				'label'       => __( 'ON/OFF Loop Content Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_content_typography',
                'label' => __('Loop Content Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .testimonial-block-one .text-box .text,
					 {{WRAPPER}} .testimonial-style-two .content-box .text
					',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_content_color',
            [
                'label' => __('Loop Content Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block-one .text-box .text' => 'color: {{VALUE}}',
					'{{WRAPPER}} .testimonial-style-two .content-box .text' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				],
            ]
        );
		//Title
		$this->add_control(
			'show_loop_author_title_style',
			[
				'label'       => __( 'ON/OFF Loop Author Title Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Loop Author Title Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .testimonial-block-one .author-box h3,
					 {{WRAPPER}} .testimonial-style-two .content-box .name
					',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_author_title_color',
            [
                'label' => __('Loop Author Title Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block-one .author-box h3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .testimonial-style-two .content-box .name' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_title_style'    => 'yes',
				]
            ]
        );
		//Designation
		$this->add_control(
			'show_loop_author_designation_style',
			[
				'label'       => __( 'ON/OFF Loop Author Designation Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_designation_typography',
                'label' => __('Loop Author Designation Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .testimonial-block-one .author-box .designation,
					 {{WRAPPER}} .testimonial-style-two .content-box .designation
					',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_designation_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_author_designation_color',
            [
                'label' => __('Loop Author Designation Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-block-one .author-box .designation' => 'color: {{VALUE}}',
					'{{WRAPPER}} .testimonial-style-two .content-box .designation' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_author_designation_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
		
		/*******************
		Arrow Styling Start
		*******************/
		$this->start_controls_section(
			'carousel_navigation_arrow',
			[
				'label' => esc_html__('Navigation - Arrow', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [ 'layout_control' => ['1','2'] ],
			]
		);
		
		/******Tabs Start**********/
		
		$this->start_controls_tabs( 'insighteye_tabs_nav_position' );
			
			$this->start_controls_tab(
				'insighteye_tab_navs_position_left',
				[
					'label' => __( 'Left Arrow', 'insighteye' ),
				]
			);
			$this->add_control(
				'arrow_position_toggle',
				[
					'label' => __( 'Position', 'insighteye' ),
					'type' => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'None', 'insighteye' ),
					'label_on' => __( 'Custom', 'insighteye' ),
					'return_value' => 'yes',
				]
			);
			/******Popup Start**********/
			$this->start_popover();
				$this->add_responsive_control(
					'arrow_position_y',
					[
						'label' => __( 'Vertical', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => ['px', '%'],
						'condition' => [
							'arrow_position_toggle' => 'yes'
						],
						'range' => [
							'px' => [
								'min' => -100,
								'max' => 500,
							],
							'%' => [
								'min' => -110,
								'max' => 110,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .bx-controls .bx-prev' => 'top: {{SIZE}}{{UNIT}};',
							'{{WRAPPER}} .nav-style-one .owl-nav button.owl-prev' => 'top: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'arrow_position_x',
					[
						'label' => __( 'Horizontal', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => ['px', '%'],
						'condition' => [
							'arrow_position_toggle' => 'yes'
						],
						'range' => [
							'px' => [
								'min' => -100,
								'max' => 500,
							],
							'%' => [
								'min' => -110,
								'max' => 110,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .bx-controls .bx-prev' => 'left: {{SIZE}}{{UNIT}};',
							'{{WRAPPER}} .nav-style-one .owl-nav button.owl-prev' => 'left: {{SIZE}}{{UNIT}};',
						],
					]
				);
			$this->end_popover();
			$this->add_control(
				'nav_arrow_position',
				[
					'label' => esc_html__( 'Position', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'relative'  => esc_html__( 'Relative', 'textdomain' ),
						'absolute' => esc_html__( 'Absolute', 'textdomain' ),
						'fixed' => esc_html__( 'Fixed', 'textdomain' ),
					],
					'selectors' => [
						'{{WRAPPER}} .bx-controls .bx-prev' => 'position: {{VALUE}};',
						'{{WRAPPER}} .nav-style-one .owl-nav button.owl-prev' => 'position: {{VALUE}};',
					],
				]
			);
			
			$this->end_controls_tab();
		
			$this->start_controls_tab(
				'insighteye_tab_navs_position_right',
				[
					'label' => __( 'Right Arrow', 'insighteye' ),
				]
			);
			$this->add_control(
				'right_arrow_position_toggle',
				[
					'label' => __( 'Position', 'insighteye' ),
					'type' => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'None', 'insighteye' ),
					'label_on' => __( 'Custom', 'insighteye' ),
					'return_value' => 'yes',
				]
			);
			$this->start_popover();
				$this->add_responsive_control(
					'right_arrow_position_y',
					[
						'label' => __( 'Vertical', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => ['px', '%'],
						'condition' => [
							'arrow_position_toggle' => 'yes'
						],
						'range' => [
							'px' => [
								'min' => -100,
								'max' => 500,
							],
							'%' => [
								'min' => -110,
								'max' => 110,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .bx-controls .bx-next' => 'top: {{SIZE}}{{UNIT}};',
							'{{WRAPPER}} .nav-style-one .owl-nav button.owl-next' => 'top: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'right_arrow_position_x',
					[
						'label' => __( 'Horizontal', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => ['px', '%'],
						'condition' => [
							'arrow_position_toggle' => 'yes'
						],
						'range' => [
							'px' => [
								'min' => -100,
								'max' => 500,
							],
							'%' => [
								'min' => -110,
								'max' => 110,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .bx-controls .bx-next' => 'right: {{SIZE}}{{UNIT}};',
							'{{WRAPPER}} .nav-style-one .owl-nav button.owl-next' => 'right: {{SIZE}}{{UNIT}};',
						],
					]
				);
			$this->end_popover();
			$this->add_control(
				'rightnav_arrow_position',
				[
					'label' => esc_html__( 'Position', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'relative'  => esc_html__( 'Relative', 'textdomain' ),
						'absolute' => esc_html__( 'Absolute', 'textdomain' ),
						'fixed' => esc_html__( 'Fixed', 'textdomain' ),
					],
					'selectors' => [
						'{{WRAPPER}} .bx-controls .bx-next' => 'position: {{VALUE}};',
						'{{WRAPPER}} .nav-style-one .owl-nav button.owl-next' => 'position: {{VALUE}};',
					],
				]
			);
		$this->end_controls_tabs();
		
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_text_typography',
                'label' => __('Button Text Typography', 'insighteye'),
                'selector' => 
					'{{WRAPPER}} .bx-controls a',				
                'separator' => 'before',
			]
        );
		$this->add_control(
			'arrow_nav_size',
			[
				'label' => __( 'Width', 'insighteye' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .bx-controls a' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .nav-style-one .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'arrow_nav_heigt_size',
			[
				'label' => __( 'Height', 'insighteye' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .bx-controls a' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .nav-style-one .owl-nav button' => 'height: {{SIZE}}{{UNIT}};'
				],
			]
		);
		
		$this->add_control(
            'arrow_border_radius',
            [
                'label' => __('Border Radius', 'insighteye'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bx-controls a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .nav-style-one .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            ]
        );
		
		$this->add_responsive_control(
			'arrow_nav_padding',
			array(
				'label'      => __('Padding', 'insighteye'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array('px', '%'),
				'selectors'  => array(
					'.owl-carousel .bx-controls a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
					'.nav-style-one .owl-nav button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				),
			)
		);
		
		$this->start_controls_tabs( 'insighteye_tabs_nav' );
		$this->start_controls_tab(
			'insighteye_tab_navs_normal',
			[
				'label' => __( 'Normal', 'insighteye' ),
			]
		);
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'navigation_border_type',
                'selector' => '{{WRAPPER}} .bx-controls a,
							   {{WRAPPER}} .nav-style-one .owl-nav button
				',				
				'separator' => 'before',
            ]
        );
		$this->add_control(
			'navigation_bg_color',
			array(
				'label'     => __('Background Color', 'insighteye'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .bx-controls a' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .nav-style-one .owl-nav button' => 'background-color: {{VALUE}}!important',
				),
			)
		);
		$this->add_control(
			'navigation_color',
			array(
				'label'     => __('Color', 'insighteye'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .bx-controls a' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .nav-style-one .owl-nav button' => 'color: {{VALUE}}!important',
				),
			)
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'insighteye_tab_nav_hover',
			[
				'label' => __( 'Hover', 'insighteye' ),
			]
		);
		$this->add_control(
            'navigation_border_hover_color',
            [
                'label' => __('Border Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .bx-controls a:hover' => 'border-color: {{VALUE}}!important',
					'{{WRAPPER}} .nav-style-one .owl-nav button:hover' => 'border-color: {{VALUE}}!important',
                ],
                'separator' => 'before',
			 ]
        );
		$this->add_control(
			'navigation_bg_hover_color',
			array(
				'label'     => __('Background Color', 'insighteye'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .bx-controls a:hover' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .nav-style-one .owl-nav button:hover' => 'background-color: {{VALUE}}!important',
					
				),
			)
		);
		$this->add_control(
			'navigation_hover_color',
			array(
				'label'     => __('Color', 'insighteye'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .bx-controls a:hover' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .nav-style-one .owl-nav button:hover' => 'color: {{VALUE}}!important',
				),
			)
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		
		/******Dots Styling Start*******/		
		$this->start_controls_section(
			'carousel_navigation_dots',
			[
				'label' => esc_html__('Navigation - Dots', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [ 'layout_control' => '1', ],
			]
		);
		$this->add_control(
			'dots_position_toggle',
			[
				'label' => __( 'Position', 'insighteye' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'label_off' => __( 'None', 'insighteye' ),
				'label_on' => __( 'Custom', 'insighteye' ),
				'return_value' => 'yes',
			]
		);
		$this->start_popover();
		$this->add_responsive_control(
			'dots_position_y',
			[
				'label' => __( 'Vertical', 'insighteye' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'condition' => [
					'dots_position_toggle' => 'yes'
				],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 500,
					],
					'%' => [
						'min' => -110,
						'max' => 110,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-carousel .owl-dots' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'dots_position_x',
			[
				'label' => __( 'Horizontal', 'insighteye' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'condition' => [
					'dots_position_toggle' => 'yes'
				],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 500,
					],
					'%' => [
						'min' => -110,
						'max' => 110,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .owl-carousel .owl-dots' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_popover();
		$this->add_control(
			'nav_dots_position',
			[
				'label' => esc_html__( 'Position', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'relative'  => esc_html__( 'Relative', 'textdomain' ),
					'absolute' => esc_html__( 'Absolute', 'textdomain' ),
					'fixed' => esc_html__( 'Fixed', 'textdomain' ),
				],
				'selectors' => [
					'{{WRAPPER}} .owl-carousel .owl-dots' => 'position: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'dots_nav_size',
			[
				'label' => __( 'Width', 'insighteye' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .owl-theme .owl-dots .owl-dot span' => 'width: {{SIZE}}{{UNIT}};'
				],
			]
		);
		$this->add_control(
			'dots_nav_heigt_size',
			[
				'label' => __( 'Height', 'insighteye' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .owl-theme .owl-dots .owl-dot span' => 'height: {{SIZE}}{{UNIT}};'
				],
			]
		);
		$this->add_control(
            'dots_border_radius',
            [
                'label' => __('Border Radius', 'insighteye'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .owl-carousel .owl-dots button span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            ]
        );
		$this->start_controls_tabs( 'insighteye_tabs_dots' );
		
		$this->start_controls_tab(
			'insighteye_tab_dots_normal',
			[
				'label' => __( 'Normal', 'insighteye' ),
			]
		);
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'dots_border_type',
                'selector' => '{{WRAPPER}} .owl-carousel .owl-dots button span',				
				'separator' => 'before',
            ]
        );
		$this->add_control(
			'dots_bg_color',
			array(
				'label'     => __('Background Color', 'insighteye'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .owl-carousel .owl-dots button span' => 'background-color: {{VALUE}}!important',
					
				),
			)
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'insighteye_tab_dots_hover',
			[
				'label' => __( 'Hover', 'insighteye' ),
			]
		);
		$this->add_control(
            'dots_border_hover_color',
            [
                'label' => __('Border Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .owl-carousel .owl-dots button span:hover' => 'border-color: {{VALUE}}!important',
					'{{WRAPPER}} .owl-carousel .owl-dots button.active span' => 'border-color: {{VALUE}}!important',
                ],
                'separator' => 'before',
			 ]
        );
		$this->add_control(
			'dots_bg_hover_color',
			array(
				'label'     => __('Background Color', 'insighteye'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .owl-carousel .owl-dots button span:hover' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .owl-carousel .owl-dots button.active span' => 'background-color: {{VALUE}}!important',
					
				),
			)
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		
		$this->end_controls_section();
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$items_show = $settings[ 'items_show' ];
		$image_item_gap = $settings[ 'image_item_gap' ];
		$autoplay_speed = $settings[ 'autoplay_speed' ];
		$layout = $settings[ 'layout_control' ];

		if($settings['infinite'] == 'yes'){
			$infiinite = true;
		}else{
			$infiinite = false;
		}

		if($settings['autoplay'] == 'yes'){
			$autoplay = true;
		}else{
			$autoplay = false;
		}

		if($settings['arrows'] == 'yes'){
			$arrows = true;
		} else{
			$arrows = false;
		}
		
		if($settings['dots'] == 'yes'){
			$dots = true;
		} else{
			$dots = false;
		}
		
		$changed_atts = array(
			'infinite'       => $infiinite,
			'autoplay'       => $autoplay,
			'autoplaySpeed'  => $autoplay_speed,
			'dots' 			 => $dots,
			'nav' 		 => $arrows,
			'item_gap' 	     => $image_item_gap,
			'item_show' 	 => $items_show
		);
		
		$slider_atts = 'data-slider';
		
		$this->add_render_attribute( 'slider_settings', $slider_atts , wp_json_encode( $changed_atts ) );
		
        $paged = insighteye_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-insighteye' );
		$args = array(
			'post_type'      => 'testimonials',
			'posts_per_page' => insighteye_set( $settings, 'query_number' ),
			'orderby'        => insighteye_set( $settings, 'query_orderby' ),
			'order'          => insighteye_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( insighteye_set( $settings, 'query_category' ) ) $args['testimonials_cat'] = insighteye_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	 { ?>
    
    	
   		<?php if( $layout === '2' ): ?>
    
        <!-- testimonial-style-two -->
        <section class="testimonial-style-two centred">
            <div class="inner-container">
                <div class="bxslider">
                    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                    <div class="slider-content">
                        <div class="content-box">
                            <ul class="rating clearfix">
                                <?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
									if(!empty($rating)){
									for ($x = 1; $x <= 5; $x++) {
										if($x <= $rating) echo '  <li><i class="icon-19"></i></li>'; else echo '<li><i class="icon-18"></i></li>';
									}
								} ?>
                            </ul>
                            <h3 class="text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></h3>
                            <h3 class="name"><?php the_title(); ?>s</h3>
                            <span class="designation"><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
                        </div>
                        <div class="slider-pager">
                            <ul class="thumb-box clearfix">
                                <li>
                                    <a class="active" data-slide-index="0" href="#">
                                        <figure class="thumb thumb-1"><?php the_post_thumbnail('insighteye_70x71'); ?></figure>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
      </section>
      <!-- testimonial-style-two end -->
    
    
    <?php else: ?>  
    
    
    <!-- testimonial-section -->
    <section class="testimonial-section pt_150">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="content-box mr_40">
                        <?php if($settings[ 'title']){ ?>
                        <div class="sec-title mb_25">
                            <span class="sub-title"><?php echo wp_kses( $settings[ 'title'], true  );?></span>
                        </div>
                        <?php } ?>
                        <div class="single-item-carousel owl-carousel owl-theme <?php if(! $settings['dots'] == 'yes' ) echo 'owl-dots-none';?> <?php if( $settings['arrows'] == 'yes' ) echo 'nav-style-one'; else echo 'owl-nav-none';?>" id="yt-testimonial-slider" <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
                        
                            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                            <div class="testimonial-block-one">
                                <div class="text-box pb_35 mb_35">
                                    <div class="text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
                                    <ul class="rating clearfix">
                                    <?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
                                        if(!empty($rating)){
                                        for ($x = 1; $x <= 5; $x++) {
                                            if($x <= $rating) echo '  <li><i class="icon-19"></i></li>'; else echo '<li><i class="icon-18"></i></li>';
                                        }
                                    } ?>
                                    </ul>
                                </div>
                                <div class="author-box">
                                    <figure class="thumb-box"><?php the_post_thumbnail('insighteye_70x71'); ?></figure>
                                    <h3><?php the_title(); ?></h3>
                                    <span class="designation"><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
                                </div>
                            </div>
                             <?php endwhile; ?>
                             
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                    <?php if($settings['feature_image']['id']){ ?>
                    <div class="image-box pr_50 pb_50 ml_40">
                        <div class="image-shape rotate-me" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-5.png);"></div>
                        <figure class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"></figure>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial-section end -->
    
    <?php endif; } 
    wp_reset_postdata();
	}

}
