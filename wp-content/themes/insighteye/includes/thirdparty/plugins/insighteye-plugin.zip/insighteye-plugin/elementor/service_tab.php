<?php namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Service_Tab extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'insighteye_service_tab';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Insighteye Service Tab', 'insighteye' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-library-open';
    }

    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'insighteye' ];
    }
	
	public function get_script_depends() {
		wp_register_script( 'tab-service', YT_URL . 'assets/js/serviec-tabs.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'tab-service' ];
	}

    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'service_tab',
            [
                'label' => esc_html__( 'Servic Tab', 'insighteye' ),
			]
        );		
		//Service Tabs Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'tabs_btn_title',
			[
				'label'       => __( 'Tab Button Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Button Title', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'block_text',
			[
				'label'       => __( 'Text', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'feture_list',
			[
				'label'       => __( 'Feture List', 'insighteye' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feture List', 'insighteye' ),
			]
		);
		$repeater->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'insighteye' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'insighteye' ),
			]
		);		
		$repeater->add_control(
			'btn_link',
			[
				  'label' => __( 'Button Url', 'insighteye' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				  'show_external' => true,
				  'default' => [
				    'url' => '',
				    'is_external' => true,
				    'nofollow' => true,
				  ],
			 ]
		);
		$repeater->add_control(
			'feature_img',
			[
				'label' => __( 'Feature Image', 'insighteye' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	
		$this->add_control(
			'our_tab',
			[
				'label'                 => __('Add Tabs Item', 'insighteye'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
        $this->end_controls_section();
    
	
		/** Style Tab **/
		$this->register_style_background_controls();
    }
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
	protected function register_style_background_controls()
	{
		/**Layout Control Style**/		
		$this->start_controls_section(
			'insighteye_layout_style',
			[
				'label' => esc_html__('Insighteye Layout Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_margin',
			[
				'label'              => __( 'Spacing', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .service-style-three' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_padding',
			[
				'label'              => __( 'Gapping', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .service-style-three' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_control(
			'insighteye_layout_background',
			[
				'label'                 => __( 'Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'insighteye_layout_bgtype',
				'label' => __( 'Button Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .service-style-three',				
			]
		);
		$this->end_controls_section();
		
		//Tab Title Style
		$this->start_controls_section(
			'tab_title_style',
			[
				'label' => esc_html__( 'Tab Title', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'tab_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .service-style-three .tab-btns .tab-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'tab_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .service-style-three .tab-btns .tab-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'tab_title_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .service-style-three .tab-btns',				
			]
		);
		$this->add_control(
			'tab_title_color',
			[
				'label' => esc_html__( 'Title Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-style-three .tab-btns .tab-btn' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tab_title_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .service-style-three .tab-btns .tab-btn',
			]
		);
		$this->end_controls_section();
		
		//Tab Active Title Style
		$this->start_controls_section(
			'tab_active_title_style',
			[
				'label' => esc_html__( 'Tab Active Title', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'tab_title_active_bgtype',
				'label' => __( 'Active Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .service-style-three .tab-btns .tab-btn:after',				
			]
		);
		$this->add_control(
			'tab_title_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-style-three .tab-btns .tab-btn.active-btn, .service-style-three .tab-btns .tab-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .service-style-three .content-box h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .service-style-three .content-box h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .service-style-three .content-box h2',				
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-style-three .content-box h2' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .service-style-three .content-box h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .service-style-three .content-box h2',
			]
		);

		$this->end_controls_section();
		
		//Text Style
		
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .service-style-three .content-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .service-style-three .content-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-style-three .content-box p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .service-style-three .content-box p',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_text_shadow',
				'selector' => '{{WRAPPER}} .service-style-three .content-box p',
			]
		);

		$this->end_controls_section();
	
	
		//Feaature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'insighteye' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'list__margin',
            [
                'label'      => esc_html__( 'Margin', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .list-style-one li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'list_padding',
            [
                'label'      => esc_html__( 'Padding', 'insighteye' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .list-style-one li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_control(
			'list_color',
			[
				'label' => esc_html__( 'List Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-style-one li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_typography',
				'label' => __('Typography', 'insighteye'),
				'selector' => '{{WRAPPER}} .list-style-one li',
			]
		);
		
		$this->add_control(
			'list_icon_color',
			[
				'label' => esc_html__( 'List Icon Color', 'insighteye' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .list-style-one li:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
            'border_color',
            [
                'label' => __('List Border Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .list-style-one li:before' => 'border-color: {{VALUE}}!important',
                ],
                'separator' => 'before',
            ]
        );
		$this->end_controls_section();
	
		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'insighteye_tabs_btn' );
		
			$this->start_controls_tab(
				'insighteye_tab_btn_normal',
				[
					'label' => __( 'Normal', 'insighteye' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-button',
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'width: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'insighteye' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'height: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'btn_margin',
					[
						'label'              => __( 'Margin', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'insighteye' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .insight-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type',
						'selector' => 
							'{{WRAPPER}} .insight-button',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' => 
							'{{WRAPPER}} .insight-button',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'insighteye'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'btn_title_typography',
						'label' => __('Button Text Typography', 'insighteye'),
						'selector' => 
							'{{WRAPPER}} .insight-button',				
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-button' => 'color: {{VALUE}}!important',
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'insighteye_tab_btn_hover',
				[
					'label' => __( 'Hover', 'insighteye' ),
				]
			);
			
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'insighteye' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .insight-button:hover:before',				
					]
				);
				
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-button:hover' => 'border-color: {{VALUE}}!important',
						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'insighteye'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .insight-button:hover' => 'color: {{VALUE}}!important',
						],
						'separator' => 'before',
					]
				);
			
			$this->end_controls_tab();			
		$this->end_controls_tabs();   
		$this->end_controls_section();
	
	}
	

   	 /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');     
	?>
    
    
    
        <!-- service-style-three -->
        <section class="service-style-three">
            <div class="tabs-box">
                <div class="tab-btns tab-buttons clearfix mb_90">
					<?php 
                        $count = 1; foreach($settings['our_tab'] as $key => $item):
                    ?>
                    <?php if($item['tabs_btn_title']) { ?>
                    <div class="tab-btn <?php if($count == 1) echo 'active-btn' ?>" data-tab="#tab-<?php echo esc_attr($count); ?>"><?php echo wp_kses($item['tabs_btn_title'], true); ?></div>
                      <?php } ?>
                    <?php  $count++; endforeach; ?>
                </div>
                <div class="tabs-content">
						<?php 
                            $count = 1; foreach($settings['our_tab'] as $key => $item):
                        ?>
                   		 <div class="tab <?php if($count == 1) echo 'active-tab' ?>" id="tab-<?php echo esc_attr($count); ?>">
                            <div class="row align-items-center">
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="content-box mr_70">
                                        <?php if($item['tabs_btn_title']) { ?>
                                        	<h2><?php echo wp_kses($item['tabs_btn_title'], true); ?></h2>
                                        <?php } ?>
                                        <?php if($item['block_text']) { ?>
                                        	<p><?php echo wp_kses($item['block_text'], true); ?></p>
                                        <?php } ?>							
                                        <?php if($item['feture_list']) { ?>
                                        <ul class="list-style-one clearfix">
                                           <?php echo wp_kses($item['feture_list'], true); ?>
                                        </ul>
                                        <?php } ?>
                                        <?php if($item['btn_title'] || $item['btn_link']['url']) { ?>
                                        <a href="<?php echo esc_url( $item['btn_link']['url'] ); ?>" class="theme-btn btn-one insight-button"><?php echo wp_kses($item['btn_title'], true);?></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <?php if($item[ 'feature_img' ]['id'] ){ ?>
                                    <div class="image-box">
                                        <div class="shape" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-10.png);"></div>
                                        <figure class="image"><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'feature_img' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'insighteye'); ?>"></figure>
                                    </div>
                                    <?php  } ?>
                                </div>
                            </div>
                        </div>
                    <?php  $count++; endforeach; ?>
                </div>
            </div>
        </section>
        <!-- service-style-three end -->
    
    
          
    
	<?php 
	}

}
