<?php namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Social_Icon extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'insighteye_social_icon';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Insighteye Social Icon', 'insighteye' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-library-open';
    }

    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'insighteye' ];
    }
	
	
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'social_icon',
            [
                'label' => esc_html__( 'Social Icon', 'insighteye' ),
            ]
        );
		
		//Social Info Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'icons',
			 [
				'label' => esc_html__('Enter The icons', 'insighteye'),
				'label_block' => true,
				'type' => Controls_Manager::SELECT2,
				'options'  => get_fontawesome_icons(),
			 ]
		);
		$repeater->add_control(
			'social_link',
			 [
				'label' => __( 'Social Link', 'insighteye' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => ['url' => '','is_external' => true,'nofollow' => true,],
			 ]
		);	
		$this->add_control(
			'social_info',
			[
				'label'                 => __('Add Social Icon Item', 'insighteye'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();
		
		/** Style Tab **/
		$this->register_style_background_controls();
    }
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
	protected function register_style_background_controls()
	{
		/**Layout Control Style**/		
		$this->start_controls_section(
			'insighteye_layout_style',
			[
				'label' => esc_html__('Insighteye Layout Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_margin',
			[
				'label'              => __( 'Spacing', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .content_block_seven' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_padding',
			[
				'label'              => __( 'Gapping', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .content_block_seven' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_control(
			'insighteye_layout_background',
			[
				'label'                 => __( 'Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'insighteye_layout_bgtype',
				'label' => __( 'Button Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .content_block_seven',				
			]
		);
		$this->end_controls_section();
	}

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
	?>
	
    
    <div class="content_block_seven"> 
        <div class="content-box">
            <div class="social-links">
                <ul class="clearfix">
                    <?php foreach($settings['social_info'] as $key => $item): ?>
                    <li><a href="<?php echo esc_url($item['social_link']['url']);?>"><span class="fab <?php echo wp_kses(str_replace( "fa ",  "", $item['icons']), true);?>"></span></a></li>
                    <?php endforeach; ?>    
                </ul>
            </div> 
         </div> 
    </div>
        
        
        
        
    <?php
    }
}
