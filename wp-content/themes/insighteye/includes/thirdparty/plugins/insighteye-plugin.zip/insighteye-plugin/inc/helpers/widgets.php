<?php
///----footer widgets---
//About Company
class Insighteye_About_Company extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Insighteye_About_Company', /* Name */esc_html__('Insighteye About Company','insighteye'), array( 'description' => esc_html__('Show the About Company', 'insighteye' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		echo wp_kses_post($before_widget);?>
        
        
            <div class="logo-widget">
            	<?php if($instance['widget_logo_img']) { ?>
                <figure class="footer-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $instance['widget_logo_img'] );?>" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"></a></figure>
                <?php } ?>
                <?php if($instance['text']) { ?>
                <div class="text-box">
                    <?php echo wp_kses( $instance[ 'text' ], true );?>
                </div>
                <?php } ?>
            </div>
        
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['widget_logo_img'] = strip_tags($new_instance['widget_logo_img']);
		$instance['text'] = $new_instance['text'];
		
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img = ($instance) ? esc_attr($instance['widget_logo_img']) : 'https://wp1.themevibrant.com/newwp/insighteye/wp-content/uploads/2023/06/logo-2.png';
		$text = ($instance) ? esc_attr($instance['text']) : '';
		
	?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>"><?php esc_html_e('Widget Logo Image: ', 'insighteye'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img')); ?>" type="text" value="<?php echo esc_attr( $widget_logo_img ); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('text')); ?>"><?php esc_html_e('Text:', 'insighteye'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('text')); ?>" name="<?php echo esc_attr($this->get_field_name('text')); ?>" ><?php echo wp_kses_post($text); ?></textarea>
        </p>
    <?php 
	}
	
}


//Contact Us
class Insighteye_Contact_Us extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Insighteye_Contact_Us', /* Name */esc_html__('Insighteye Contact Us','insighteye'), array( 'description' => esc_html__('Show the Contact Us', 'insighteye' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);
		?>
            <div class="contact-widget">
               	<?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="widget-content">
                    <?php if($instance[ 'text']){ ?><p><?php echo wp_kses( $instance[ 'text' ], true );?></p><?php } ?>
                    <ul class="info-list clearfix">
                        <?php if($instance[ 'footer_widget_address' ]) {?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-6.svg" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"><?php echo wp_kses( $instance[ 'footer_widget_address' ], true );?></li><?php } ?>
                        <?php if($instance[ 'footer_widget_email' ]) {?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-7.svg" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"><a href="mailto:<?php echo esc_attr( $instance[ 'footer_widget_email' ], true );?>"><?php echo wp_kses( $instance[ 'footer_widget_email' ], true );?></a></li><?php } ?>
                        <?php if($instance[ 'footer_widget_phone_no' ]) {?><li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-8.svg" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"><a href="tel:<?php echo esc_attr( $instance[ 'footer_widget_phone_no' ], true );?>"><?php echo wp_kses( $instance[ 'footer_widget_phone_no' ], true );?></a></li><?php } ?>
                    </ul>
                </div>
            </div>
        
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['text'] = $new_instance['text'];
		$instance['footer_widget_address'] = $new_instance['footer_widget_address'];
		$instance['footer_widget_email'] = $new_instance['footer_widget_email'];
		$instance['footer_widget_phone_no'] = $new_instance['footer_widget_phone_no'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$text = ($instance) ? esc_attr($instance['text']) : '';
		$footer_widget_address = ($instance) ? esc_attr($instance['footer_widget_address']) : '';
		$footer_widget_email = ($instance) ? esc_attr($instance['footer_widget_email']) : '';
		$footer_widget_phone_no = ($instance) ? esc_attr($instance['footer_widget_phone_no']) : '';
	?>
    
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'insighteye'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
    </p>
     <p>
        <label for="<?php echo esc_attr($this->get_field_id('text')); ?>"><?php esc_html_e('Text:', 'insighteye'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('text')); ?>" name="<?php echo esc_attr($this->get_field_name('text')); ?>" ><?php echo wp_kses_post($text); ?></textarea>
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('footer_widget_address')); ?>"><?php esc_html_e('Address:', 'insighteye'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_widget_address')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_widget_address')); ?>" ><?php echo wp_kses_post($footer_widget_address); ?></textarea>
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('footer_widget_email')); ?>"><?php esc_html_e('Email Address: ', 'insighteye'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_widget_email')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_widget_email')); ?>" type="text" value="<?php echo esc_attr( $footer_widget_email ); ?>" />
    </p>  
     <p>
        <label for="<?php echo esc_attr($this->get_field_id('footer_widget_phone_no')); ?>"><?php esc_html_e('Phone Number: ', 'insighteye'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_widget_phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_widget_phone_no')); ?>" type="text" value="<?php echo esc_attr( $footer_widget_phone_no ); ?>" />
    </p>
    
    <?php 
	}
	
}

///----Service widgets---
//Appoinment
class Insighteye_Appoinment extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Insighteye_Appoinment', /* Name */esc_html__('Insighteye Appoinment','insighteye'), array( 'description' => esc_html__('Show the Appoinment', 'insighteye' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);
		?>
        	
            <div class="support-widget">
                <?php if( $instance['widget_men_img']){ ?>
                <div class="shape" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-16.png);"></div>
                <figure class="image-layer"><img src="<?php echo esc_url( $instance['widget_men_img'] );?>" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"></figure>
                <?php } ?>
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <?php if($instance[ 'text']){ ?><p><?php echo wp_kses( $instance[ 'text' ], true );?></p><?php } ?>
                <?php if($instance[ 'footer_widget_phone_no' ]) {?>
                <div class="phone-box">
                    <div class="icon-box"><div class="icon gradient-color"><i class="icon-20"></i></div></div>
                    <a href="tel:<?php echo esc_attr( $instance[ 'footer_widget_phone_no' ], true );?>"><?php echo wp_kses( $instance[ 'footer_widget_phone_no' ], true );?></a>
                </div>
                <?php } ?>
            </div>
            
        
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['widget_men_img'] = $new_instance['widget_men_img'];
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['text'] = $new_instance['text'];
		$instance['footer_widget_phone_no'] = $new_instance['footer_widget_phone_no'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_men_img = ($instance) ? esc_attr($instance['widget_men_img']) : 'https://wp1.themevibrant.com/newwp/insighteye/wp-content/uploads/2023/07/men-2.png';
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$text = ($instance) ? esc_attr($instance['text']) : '';
		$footer_widget_phone_no = ($instance) ? esc_attr($instance['footer_widget_phone_no']) : '';
	?>
    
     <p>
        <label for="<?php echo esc_attr($this->get_field_id('widget_men_img')); ?>"><?php esc_html_e('Widget Men Image: ', 'insighteye'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_men_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_men_img')); ?>" type="text" value="<?php echo esc_attr( $widget_men_img ); ?>" />
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'insighteye'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
    </p>
     <p>
        <label for="<?php echo esc_attr($this->get_field_id('text')); ?>"><?php esc_html_e('Text:', 'insighteye'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('text')); ?>" name="<?php echo esc_attr($this->get_field_name('text')); ?>" ><?php echo wp_kses_post($text); ?></textarea>
    </p>
     <p>
        <label for="<?php echo esc_attr($this->get_field_id('footer_widget_phone_no')); ?>"><?php esc_html_e('Phone Number: ', 'insighteye'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_widget_phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_widget_phone_no')); ?>" type="text" value="<?php echo esc_attr( $footer_widget_phone_no ); ?>" />
    </p>
    
    <?php 
	}
	
}

///----Blog widgets---
//Recent Posts
class Insighteye_Recent_Posts extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Insighteye_Recent_Posts', /* Name */esc_html__('Insighteye Recent Posts','insighteye'), array( 'description' => esc_html__('Show the Recent Posts', 'insighteye' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

		echo wp_kses_post($before_widget); ?>
		 <div class="post-widget">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="post-inner">
               <?php $query_string = array('showposts'=>$instance['number']);
				if ($instance['cat']) {
					$query_string['tax_query'] = array(array('taxonomy' => 'category','field' => 'id','terms' => (array)$instance['cat']));
				}
				$this->posts($query_string); ?>   
            </div>
        </div>
        
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/* @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/* @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Recent Posts', 'insighteye');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'insighteye'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'insighteye'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'insighteye'); ?></label>
            <?php wp_dropdown_categories(array('show_option_all'=>esc_html__('All Categories', 'insighteye'), 'taxonomy' => 'category', 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('cat'))); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while ( $query->have_posts() ) : $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            
            <div class="post">
                <figure class="post-thumb"><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><img src="<?php echo esc_url($post_thumbnail_url);?>" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"></a></figure>
                <h6><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h6>
                <span class="post-date"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icons/icon-13.svg" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"> <?php echo get_the_date('');?></span>
            </div>
                  
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

//Gallery 
class Insighteye_Gallery extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Insighteye_Gallery', /* Name */esc_html__('Insighteye Gallery','insighteye'), array( 'description' => esc_html__('Show the Gallery', 'insighteye' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

		echo wp_kses_post($before_widget); ?>
        
         <div class="gallery-widget">
           	<?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <ul class="image-list clearfix">
                     <?php $query_string = array('showposts'=>$instance['number']);
					if ($instance['cat']) {
						$query_string['tax_query'] = array(array('taxonomy' => 'category','field' => 'id','terms' => (array)$instance['cat']));
					}
					$this->posts($query_string); ?> 
                </ul>
            </div>
        </div>

		<?php echo wp_kses_post($after_widget);
	}
 
 
	/* @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/* @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Recent Posts', 'insighteye');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'insighteye'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'insighteye'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'insighteye'); ?></label>
            <?php wp_dropdown_categories(array('show_option_all'=>esc_html__('All Categories', 'insighteye'), 'taxonomy' => 'category', 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('cat'))); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while ( $query->have_posts() ) : $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            
            <li>
                <figure class="image"><a href="<?php echo esc_url($post_thumbnail_url);?>" class="lightbox-image" data-fancybox="gallery"><img src="<?php echo esc_url($post_thumbnail_url);?>" alt="<?php esc_attr_e( 'Awesome Image', 'insighteye' );?>"></a></figure>
            </li>
                 
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

