<?php

namespace INSIGHTEYEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Project_Grid extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'insighteye_project_grid';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Insighteye Project Grid', 'insighteye' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'insighteye' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'project_grid',
			[
				'label' => esc_html__( 'Project Grid', 'insighteye' ),
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'insighteye' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'insighteye' ),
					'title'      => esc_html__( 'Title', 'insighteye' ),
					'menu_order' => esc_html__( 'Menu Order', 'insighteye' ),
					'rand'       => esc_html__( 'Random', 'insighteye' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'insighteye' ),
					'ASC'  => esc_html__( 'ASC', 'insighteye' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
				'type' => Controls_Manager::SELECT,
				'label' => esc_html__('Category', 'insighteye'),
				'label_block' => true,
				'options' => get_project_categories()
			]
		);
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'insighteye' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'three',
				'options' => array(
					'one' => esc_html__( 'One Column Grid ', 'insighteye'),
					'two'  => esc_html__( 'Two Column Grid', 'insighteye' ),
					'three'  => esc_html__( 'Three Column Grid', 'insighteye' ),
					'four'  => esc_html__( 'Four Column Grid', 'insighteye' ),
					'five'  => esc_html__( 'Six Column Grid', 'insighteye' ),
				),
				'condition'             => [
					'style_two'    => 'one', 
				]
			]
		);
		$this->end_controls_section();
		
		
		/************************************************************************
									Tab Style Start
		*************************************************************************/
	
		/**Layout Control Style**/		
		$this->start_controls_section(
			'insighteye_layout_style',
			[
				'label' => esc_html__('Insighteye Layout Setting', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_margin',
			[
				'label'              => __( 'Spacing', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .case-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_responsive_control(
			'insighteye_layout_padding',
			[
				'label'              => __( 'Gapping', 'insighteye' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .case-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_control(
			'insighteye_layout_background',
			[
				'label'                 => __( 'Background', 'insighteye' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'insighteye_layout_bgtype',
				'label' => __( 'Button Background', 'insighteye' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .case-section',
			]
		);
		$this->end_controls_section();
		
		/**Loop Item Style**/
		$this->start_controls_section(
			'loop_item_style',
			[
				'label' => esc_html__('Loop Item Style Settings', 'insighteye'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		//Loop Title
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF  Loop Title Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Loop Title Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .case-block-one .inner-box .content-box h3',               
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Loop Title Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .case-block-one .inner-box .content-box h3 a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_hover_color',
            [
                'label' => __('Loop Title Hover Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .case-block-one .inner-box .content-box h3 a:hover' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		
		//Loop Category
		$this->add_control(
			'show_loop_category_style',
			[
				'label'       => __( 'ON/OFF Loop Category Style', 'insighteye' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'insighteye' ),
				'label_off' => esc_html__( 'Hide', 'insighteye' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_category_typography',
                'label' => __('Loop Category Typography', 'insighteye'),
                'selector' => 
                    '{{WRAPPER}} .case-block-one .inner-box .content-box p',               
                'separator' => 'before',
				'condition'             => [
					'show_loop_category_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_category_color',
            [
                'label' => __('Loop Category Color', 'insighteye'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .case-block-one .inner-box .content-box p' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_category_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$grid_col = $settings['col_grid'];
		
		if( $grid_col === 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-6 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}
		
        $paged = insighteye_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-insighteye' );
		$args = array(
			'post_type'      => 'project',
			'posts_per_page' => insighteye_set( $settings, 'query_number' ),
			'orderby'        => insighteye_set( $settings, 'query_orderby' ),
			'order'          => insighteye_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( insighteye_set( $settings, 'query_category' ) ) $args['project_cat'] = insighteye_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	{ ?>
        
     <!-- case-section -->
     <div class="case-section">
          <div class="row clearfix">
			<?php
                global $post;
                while ( $query->have_posts() ) : $query->the_post(); 
                $term_list = wp_get_post_terms(get_the_id(), 'project_cat', array("fields" => "names"));
                $post_thumbnail_id = get_post_thumbnail_id($post->ID);
                $post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id ); 
           ?>
            <div class="<?php echo esc_attr( $classes );?> case-block">
                <div class="case-block-one wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                    <div class="inner-box">
                        <figure class="image-box"><?php the_post_thumbnail( 'insighteye_410x413' ); ?></figure>
                        <div class="view-btn"><a href="<?php echo esc_url( $post_thumbnail_url );?>" class="lightbox-image" data-fancybox="gallery"><i class="icon-5"></i></a></div>
                        <div class="content-box centred">
                            <div class="shape">
                                <div class="shape-1" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-12.png);"></div>
                                <div class="shape-2" style="background-image: url(<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/shape/shape-13.png);"></div>
                            </div>
                            <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                            <p><?php echo implode( ', ', (array)$term_list );?></p>
                        </div>
                    </div>
                </div>
            </div>
           <?php endwhile; ?>
        </div>
    </div> 
    
	<?php }
    wp_reset_postdata();
	}

}
